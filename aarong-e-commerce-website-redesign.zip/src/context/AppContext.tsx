import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import type { CartItem, Product } from '../data/products';

interface AppContextType {
  // Navigation
  currentPage: string;
  setCurrentPage: (page: string) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  selectedProduct: Product | null;
  setSelectedProduct: (p: Product | null) => void;

  // Cart
  cart: CartItem[];
  addToCart: (product: Product, color: string, size: string, qty?: number) => void;
  removeFromCart: (id: string, color: string, size: string) => void;
  updateQuantity: (id: string, color: string, size: string, qty: number) => void;
  clearCart: () => void;
  cartCount: number;
  cartTotal: number;

  // Wishlist
  wishlist: Product[];
  toggleWishlist: (product: Product) => void;
  isWishlisted: (id: string) => boolean;

  // UI State
  isCartOpen: boolean;
  setIsCartOpen: (v: boolean) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (v: boolean) => void;
  isMobileMenuOpen: boolean;
  setIsMobileMenuOpen: (v: boolean) => void;
  isWishlistOpen: boolean;
  setIsWishlistOpen: (v: boolean) => void;

  // Search
  searchQuery: string;
  setSearchQuery: (q: string) => void;

  // User
  isLoggedIn: boolean;
  setIsLoggedIn: (v: boolean) => void;
  user: { name: string; email: string; points: number } | null;

  // Notifications
  notification: { message: string; type: 'success' | 'error' | 'info' } | null;
  showNotification: (message: string, type?: 'success' | 'error' | 'info') => void;

  // Coupon
  appliedCoupon: string;
  setAppliedCoupon: (c: string) => void;
  discount: number;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentPage, setCurrentPage] = useState('home');
  const [selectedCategory, setSelectedCategory] = useState('women');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<Product[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [notification, setNotification] = useState<AppContextType['notification']>(null);
  const [appliedCoupon, setAppliedCoupon] = useState('');
  const [discount, setDiscount] = useState(0);

  const user = isLoggedIn ? { name: 'Priya Rahman', email: 'priya@example.com', points: 2450 } : null;

  const showNotification = useCallback((message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3500);
  }, []);

  const addToCart = useCallback((product: Product, color: string, size: string, qty = 1) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === product.id && i.selectedColor === color && i.selectedSize === size);
      if (existing) {
        return prev.map(i =>
          i.id === product.id && i.selectedColor === color && i.selectedSize === size
            ? { ...i, quantity: i.quantity + qty }
            : i
        );
      }
      return [...prev, { ...product, quantity: qty, selectedColor: color, selectedSize: size }];
    });
    showNotification(`${product.name} added to cart!`);
  }, [showNotification]);

  const removeFromCart = useCallback((id: string, color: string, size: string) => {
    setCart(prev => prev.filter(i => !(i.id === id && i.selectedColor === color && i.selectedSize === size)));
    showNotification('Item removed from cart', 'info');
  }, [showNotification]);

  const updateQuantity = useCallback((id: string, color: string, size: string, qty: number) => {
    if (qty < 1) return;
    setCart(prev => prev.map(i =>
      i.id === id && i.selectedColor === color && i.selectedSize === size ? { ...i, quantity: qty } : i
    ));
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const toggleWishlist = useCallback((product: Product) => {
    setWishlist(prev => {
      const exists = prev.find(p => p.id === product.id);
      if (exists) {
        showNotification('Removed from wishlist', 'info');
        return prev.filter(p => p.id !== product.id);
      }
      showNotification('Added to wishlist ♥', 'success');
      return [...prev, product];
    });
  }, [showNotification]);

  const isWishlisted = useCallback((id: string) => wishlist.some(p => p.id === id), [wishlist]);

  const cartCount = cart.reduce((sum, i) => sum + i.quantity, 0);
  const cartTotal = cart.reduce((sum, i) => sum + i.price * i.quantity, 0);

  useEffect(() => {
    if (appliedCoupon === 'AARONG10') setDiscount(0.10);
    else if (appliedCoupon === 'EID2024') setDiscount(0.15);
    else if (appliedCoupon === 'WELCOME20') setDiscount(0.20);
    else setDiscount(0);
  }, [appliedCoupon]);

  return (
    <AppContext.Provider value={{
      currentPage, setCurrentPage,
      selectedCategory, setSelectedCategory,
      selectedProduct, setSelectedProduct,
      cart, addToCart, removeFromCart, updateQuantity, clearCart,
      cartCount, cartTotal,
      wishlist, toggleWishlist, isWishlisted,
      isCartOpen, setIsCartOpen,
      isSearchOpen, setIsSearchOpen,
      isMobileMenuOpen, setIsMobileMenuOpen,
      isWishlistOpen, setIsWishlistOpen,
      searchQuery, setSearchQuery,
      isLoggedIn, setIsLoggedIn, user,
      notification, showNotification,
      appliedCoupon, setAppliedCoupon, discount,
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
};
