import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import Header from './components/Header';
import Footer from './components/Footer';
import CartDrawer from './components/CartDrawer';
import WishlistDrawer from './components/WishlistDrawer';
import Notification from './components/Notification';
import HomePage from './pages/HomePage';
import CategoryPage from './pages/CategoryPage';
import ProductDetailPage from './pages/ProductDetailPage';
import CheckoutPage from './pages/CheckoutPage';
import AccountPage from './pages/AccountPage';
import AuthPage from './pages/AuthPage';
import StoreLocatorPage from './pages/StoreLocatorPage';
import SupportPage from './pages/SupportPage';
import AIStylistPage from './pages/AIStylistPage';

const AppContent: React.FC = () => {
  const { currentPage } = useApp();

  // Scroll to top on page change
  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentPage]);

  // Pages that show header+footer
  const hasHeaderFooter = !['checkout', 'auth'].includes(currentPage);

  const renderPage = () => {
    switch (currentPage) {
      case 'home': return <HomePage />;
      case 'category': return <CategoryPage />;
      case 'product': return <ProductDetailPage />;
      case 'checkout': return <CheckoutPage />;
      case 'account': return <AccountPage />;
      case 'auth': return <AuthPage />;
      case 'store-locator': return <StoreLocatorPage />;
      case 'support': case 'contact': return <SupportPage />;
      case 'ai-stylist': return <AIStylistPage />;
      case 'track-order': return <AccountPage />;
      case 'about': return <AboutPage />;
      default: return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {hasHeaderFooter && <Header />}
      <main className="flex-1">
        {renderPage()}
      </main>
      {hasHeaderFooter && currentPage !== 'checkout' && currentPage !== 'auth' && <Footer />}
      <CartDrawer />
      <WishlistDrawer />
      <Notification />
    </div>
  );
};

// Inline About Page
const AboutPage: React.FC = () => {
  const { setCurrentPage } = useApp();
  const milestones = [
    { year: '1978', title: 'The Beginning', desc: 'Aarong is founded in Manikganj by BRAC to provide rural artisans with a sustainable market for their crafts.' },
    { year: '1987', title: 'Growing Nationwide', desc: 'Expansion to multiple cities as Aarong becomes a household name across Bangladesh.' },
    { year: '2000', title: 'Heritage Preservation', desc: 'UNESCO acknowledges Aarong\'s role in preserving traditional Bangladeshi crafts including Jamdani and Nakshi Kantha.' },
    { year: '2014', title: 'Digital Revolution', desc: 'Launch of official e-commerce platform, bringing handcrafted Bengali artistry to the world online.' },
    { year: '2020', title: 'Pandemic Resilience', desc: 'Digital presence becomes a vital channel, supporting 65,000+ artisans through COVID-19 challenges.' },
    { year: '2025', title: 'World\'s Largest Craft Store', desc: 'New 60,000 sq ft flagship in Dhanmondi, Dhaka — the world\'s largest craft store. 30th outlet opens in Noakhali.' },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <div className="relative h-[60vh] overflow-hidden">
        <img src="/images/brand-story.jpg" alt="About Aarong" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#2C1810]/90 via-[#2C1810]/40 to-transparent" />
        <div className="absolute bottom-0 left-0 p-12">
          <span className="text-[#F5E6C8] text-xs tracking-[0.3em] uppercase font-bold">Est. 1978 · A BRAC Social Enterprise</span>
          <h1 className="text-5xl font-light text-white mt-3" style={{ fontFamily: 'Georgia, serif' }}>
            Our Story
          </h1>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 md:px-8 py-16">
        {/* Mission */}
        <div className="text-center mb-16">
          <h2 className="text-3xl font-light text-[#2C1810] mb-6" style={{ fontFamily: 'Georgia, serif' }}>
            More Than a Store —<br /><em className="font-bold italic text-[#C0392B]">A Cultural Movement</em>
          </h2>
          <p className="text-[#6B4C3B] leading-relaxed max-w-2xl mx-auto text-lg">
            Aarong (Bengali: আড়ং, meaning "Village Fair") was born from a simple but powerful belief: that traditional Bangladeshi craftsmanship deserves a global stage, and that rural artisans deserve dignified livelihoods.
          </p>
        </div>

        {/* Values */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          {[
            { icon: '🌿', title: 'Empowerment', desc: 'Over 65,000 artisans — mostly women — are empowered through fair wages, training, and dignified work.' },
            { icon: '🏺', title: 'Preservation', desc: 'We preserve centuries-old craft traditions: Jamdani weaving, Nakshi Kantha embroidery, block printing, brass work.' },
            { icon: '🌍', title: 'Sustainability', desc: 'Aarong Earth and our Eco-Craft initiative champion organic materials, natural dyes, and sustainable production.' },
          ].map((v, i) => (
            <div key={i} className="bg-[#FAF7F2] rounded-2xl p-6 border border-[#E8D5B0] text-center">
              <div className="text-4xl mb-4">{v.icon}</div>
              <h3 className="font-bold text-[#2C1810] mb-2" style={{ fontFamily: 'Georgia, serif' }}>{v.title}</h3>
              <p className="text-sm text-[#6B4C3B] leading-relaxed">{v.desc}</p>
            </div>
          ))}
        </div>

        {/* Timeline */}
        <div className="mb-16">
          <h2 className="text-3xl font-light text-[#2C1810] mb-10 text-center" style={{ fontFamily: 'Georgia, serif' }}>Our Journey</h2>
          <div className="relative">
            <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-[#E8D5B0] -translate-x-1/2" />
            <div className="space-y-8">
              {milestones.map((m, i) => (
                <div key={m.year} className={`flex gap-8 items-center ${i % 2 === 0 ? 'flex-row' : 'flex-row-reverse'}`}>
                  <div className={`flex-1 ${i % 2 === 0 ? 'text-right' : 'text-left'}`}>
                    <div className={`bg-white border border-[#E8D5B0] rounded-2xl p-5 shadow-sm hover:shadow-md transition-shadow ${i % 2 === 0 ? 'ml-auto' : 'mr-auto'} max-w-sm`}>
                      <p className="text-xs font-bold text-[#C0392B] tracking-wider mb-1">{m.year}</p>
                      <h3 className="font-bold text-[#2C1810] mb-2">{m.title}</h3>
                      <p className="text-sm text-[#6B4C3B] leading-relaxed">{m.desc}</p>
                    </div>
                  </div>
                  <div className="flex-shrink-0 w-10 h-10 bg-[#C0392B] rounded-full flex items-center justify-center text-white text-xs font-bold z-10 shadow-lg">
                    {m.year.slice(-2)}
                  </div>
                  <div className="flex-1" />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* BRAC Connection */}
        <div className="bg-gradient-to-br from-[#2C1810] to-[#8B4513] rounded-3xl p-10 text-white text-center mb-16">
          <h2 className="text-3xl font-light mb-4" style={{ fontFamily: 'Georgia, serif' }}>The BRAC Connection</h2>
          <p className="text-white/80 leading-relaxed max-w-2xl mx-auto mb-6">
            Aarong is wholly owned by BRAC — the world's largest non-governmental development organization. Every purchase you make at Aarong directly funds BRAC's programs in education, healthcare, microfinance, and livelihood development for millions of Bangladeshis.
          </p>
          <div className="grid grid-cols-3 gap-6">
            {[
              { value: '46+', label: 'Years of Impact' },
              { value: '30', label: 'Countries' },
              { value: '100M+', label: 'Lives Touched by BRAC' },
            ].map((s, i) => (
              <div key={i}>
                <p className="text-3xl font-bold text-[#F5E6C8]">{s.value}</p>
                <p className="text-white/70 text-sm">{s.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <h2 className="text-2xl font-light text-[#2C1810] mb-4" style={{ fontFamily: 'Georgia, serif' }}>Experience Aarong</h2>
          <p className="text-[#6B4C3B] mb-6">Shop our collection and become part of this beautiful story</p>
          <div className="flex gap-4 justify-center">
            <button onClick={() => setCurrentPage('category')} className="px-8 py-4 bg-[#C0392B] text-white rounded-full font-semibold hover:bg-[#A93226] transition-colors">
              Shop Collection
            </button>
            <button onClick={() => setCurrentPage('store-locator')} className="px-8 py-4 border-2 border-[#2C1810] text-[#2C1810] rounded-full font-semibold hover:bg-[#2C1810] hover:text-white transition-all">
              Visit a Store
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
};

export default App;
