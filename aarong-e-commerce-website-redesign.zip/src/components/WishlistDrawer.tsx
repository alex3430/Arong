import React from 'react';
import { X, Heart, ShoppingBag, Share2, Trash2 } from 'lucide-react';
import { useApp } from '../context/AppContext';

const WishlistDrawer: React.FC = () => {
  const { isWishlistOpen, setIsWishlistOpen, wishlist, toggleWishlist, addToCart, setCurrentPage, setSelectedProduct } = useApp();

  return (
    <>
      <div
        className={`fixed inset-0 bg-black/50 backdrop-blur-sm z-50 transition-opacity duration-300 ${isWishlistOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={() => setIsWishlistOpen(false)}
      />
      <div className={`fixed right-0 top-0 h-full w-full sm:w-[400px] bg-white z-50 shadow-2xl flex flex-col transform transition-transform duration-400 ease-out ${isWishlistOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#E8D5B0] bg-[#FAF7F2]">
          <div className="flex items-center gap-3">
            <Heart className="text-[#C0392B] fill-[#C0392B]" size={22} />
            <div>
              <h2 className="font-semibold text-[#2C1810] text-lg" style={{ fontFamily: 'Georgia, serif' }}>My Wishlist</h2>
              <p className="text-xs text-[#8B4513]">{wishlist.length} saved items</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {wishlist.length > 0 && (
              <button className="p-2 text-[#6B4C3B] hover:text-[#C0392B] transition-colors">
                <Share2 size={18} />
              </button>
            )}
            <button onClick={() => setIsWishlistOpen(false)} className="p-2 text-[#6B4C3B] hover:text-[#C0392B] hover:bg-[#F0E6D3] rounded-full transition-all">
              <X size={20} />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-4">
          {wishlist.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center gap-4">
              <div className="w-24 h-24 bg-[#F0E6D3] rounded-full flex items-center justify-center">
                <Heart className="text-[#C8A87E]" size={36} />
              </div>
              <h3 className="font-semibold text-[#3D2B1F]" style={{ fontFamily: 'Georgia, serif' }}>Your wishlist is empty</h3>
              <p className="text-sm text-[#8B4513]">Save items you love to revisit later</p>
              <button
                onClick={() => { setIsWishlistOpen(false); setCurrentPage('category'); }}
                className="px-6 py-3 bg-[#C0392B] text-white rounded-full text-sm font-medium hover:bg-[#A93226] transition-colors"
              >
                Explore Collection
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {wishlist.map(item => (
                <div key={item.id} className="flex gap-3 p-3 bg-[#FAF7F2] rounded-xl border border-[#E8D5B0]">
                  <button
                    onClick={() => { setSelectedProduct(item); setCurrentPage('product'); setIsWishlistOpen(false); }}
                    className="w-20 h-20 rounded-lg overflow-hidden bg-white flex-shrink-0"
                  >
                    <img src={item.images[0]} alt={item.name} className="w-full h-full object-cover hover:scale-105 transition-transform duration-300" />
                  </button>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <button
                        onClick={() => { setSelectedProduct(item); setCurrentPage('product'); setIsWishlistOpen(false); }}
                        className="text-left"
                      >
                        <p className="text-sm font-medium text-[#2C1810] line-clamp-2 hover:text-[#C0392B] transition-colors">{item.name}</p>
                      </button>
                      <button onClick={() => toggleWishlist(item)} className="text-[#C0392B] hover:text-[#A93226] transition-colors flex-shrink-0 ml-2">
                        <Trash2 size={14} />
                      </button>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-sm font-bold text-[#C0392B]">৳{item.price.toLocaleString()}</span>
                      {item.originalPrice && (
                        <span className="text-xs text-[#A07850] line-through">৳{item.originalPrice.toLocaleString()}</span>
                      )}
                    </div>
                    <button
                      onClick={() => {
                        addToCart(item, item.colors[0], item.sizes[0]);
                        toggleWishlist(item);
                      }}
                      className="mt-2 w-full py-1.5 bg-[#2C1810] text-white rounded-full text-xs font-medium hover:bg-[#C0392B] transition-colors flex items-center justify-center gap-1"
                    >
                      <ShoppingBag size={12} /> Move to Bag
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default WishlistDrawer;
