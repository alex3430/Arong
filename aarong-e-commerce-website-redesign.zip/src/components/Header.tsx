import React, { useState, useEffect, useRef } from 'react';
import {
  Search, ShoppingBag, Heart, User, MapPin, Globe, Menu, X,
  ChevronDown, Mic, Sparkles, Bell, Phone
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { categories, products } from '../data/products';

const AnnouncementBar: React.FC = () => (
  <div className="bg-[#2C1810] text-[#F5E6C8] text-xs py-2 px-4 text-center font-light tracking-widest">
    <span className="mr-6">🌿 FREE SHIPPING ON ORDERS OVER ৳3,000</span>
    <span className="mr-6">|</span>
    <span className="mr-6">✦ EID COLLECTION NOW LIVE</span>
    <span className="mr-6">|</span>
    <span>USE CODE <strong>EID2024</strong> FOR 15% OFF</span>
  </div>
);

const MegaMenu: React.FC<{ category: typeof categories[0]; onNavigate: (page: string, cat: string) => void }> = ({ category, onNavigate }) => {
  const featuredProducts = products.filter(p => p.category === category.id || p.isFeatured).slice(0, 2);

  return (
    <div className="absolute top-full left-0 right-0 bg-white shadow-2xl border-t border-[#E8D5B0] z-50 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300">
      <div className="max-w-7xl mx-auto px-8 py-8 grid grid-cols-4 gap-8">
        <div className="col-span-1">
          <h3 className="text-xs font-bold tracking-[0.2em] text-[#8B4513] uppercase mb-4">Browse {category.label}</h3>
          <ul className="space-y-2">
            {category.subcategories.map(sub => (
              <li key={sub}>
                <button
                  onClick={() => onNavigate('category', category.id)}
                  className="text-sm text-[#3D2B1F] hover:text-[#C0392B] transition-colors py-1 block w-full text-left hover:translate-x-1 transform duration-200"
                >
                  {sub}
                </button>
              </li>
            ))}
            <li>
              <button
                onClick={() => onNavigate('category', category.id)}
                className="text-sm font-semibold text-[#C0392B] mt-2 flex items-center gap-1"
              >
                View All {category.label} →
              </button>
            </li>
          </ul>
        </div>
        <div className="col-span-2">
          <h3 className="text-xs font-bold tracking-[0.2em] text-[#8B4513] uppercase mb-4">Featured Products</h3>
          <div className="grid grid-cols-2 gap-4">
            {featuredProducts.map(p => (
              <button
                key={p.id}
                onClick={() => onNavigate('product', p.id)}
                className="group/card text-left"
              >
                <div className="aspect-square rounded-lg overflow-hidden mb-2 bg-[#F9F3EA]">
                  <img src={p.images[0]} alt={p.name} className="w-full h-full object-cover group-hover/card:scale-105 transition-transform duration-300" />
                </div>
                <p className="text-xs font-medium text-[#3D2B1F] line-clamp-1">{p.name}</p>
                <p className="text-xs text-[#8B4513] font-semibold">৳{p.price.toLocaleString()}</p>
              </button>
            ))}
          </div>
        </div>
        <div className="col-span-1">
          <h3 className="text-xs font-bold tracking-[0.2em] text-[#8B4513] uppercase mb-4">Collections</h3>
          <div className="space-y-3">
            {['New Arrivals', 'Best Sellers', 'Sale', 'Heritage Picks', 'Eid Special'].map(c => (
              <button key={c} onClick={() => onNavigate('category', category.id)}
                className="block w-full text-left text-sm text-[#3D2B1F] hover:text-[#C0392B] transition-colors py-1 border-b border-[#F0E6D3]">
                {c}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const Header: React.FC = () => {
  const {
    cartCount, setIsCartOpen, isWishlistOpen, setIsWishlistOpen,
    setIsSearchOpen, isMobileMenuOpen, setIsMobileMenuOpen,
    isLoggedIn, user, setCurrentPage, setSelectedCategory, wishlist,
    setSelectedProduct,
  } = useApp();

  const [scrolled, setScrolled] = useState(false);
  const [searchVal, setSearchVal] = useState('');
  const [searchResults, setSearchResults] = useState<typeof products>([]);
  const [showSearch, setShowSearch] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearch = (q: string) => {
    setSearchVal(q);
    if (q.length > 1) {
      const results = products.filter(p =>
        p.name.toLowerCase().includes(q.toLowerCase()) ||
        p.category.toLowerCase().includes(q.toLowerCase()) ||
        p.description.toLowerCase().includes(q.toLowerCase())
      ).slice(0, 5);
      setSearchResults(results);
      setShowSearch(true);
    } else {
      setShowSearch(false);
    }
  };

  const navigate = (page: string, catOrId?: string) => {
    if (page === 'product') {
      const prod = products.find(p => p.id === catOrId);
      if (prod) {
        setSelectedProduct(prod);
        setCurrentPage('product');
      }
    } else if (page === 'category') {
      setSelectedCategory(catOrId || 'women');
      setCurrentPage('category');
    } else {
      setCurrentPage(page);
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <AnnouncementBar />
      <header className={`sticky top-0 z-40 transition-all duration-300 ${scrolled ? 'bg-white/95 backdrop-blur-md shadow-md' : 'bg-white'}`}>
        {/* Top utility bar */}
        <div className="border-b border-[#E8D5B0] bg-[#FAF7F2]">
          <div className="max-w-7xl mx-auto px-4 lg:px-8 flex items-center justify-between py-2">
            <div className="flex items-center gap-4 text-xs text-[#6B4C3B]">
              <button onClick={() => navigate('store-locator')} className="flex items-center gap-1 hover:text-[#C0392B] transition-colors">
                <MapPin size={12} /> Store Locator
              </button>
              <span className="text-[#C8A87E]">|</span>
              <button className="flex items-center gap-1 hover:text-[#C0392B] transition-colors">
                <Phone size={12} /> +880 1600 000000
              </button>
              <span className="text-[#C8A87E]">|</span>
              <button onClick={() => navigate('track-order')} className="hover:text-[#C0392B] transition-colors">Track Order</button>
            </div>
            <div className="flex items-center gap-4 text-xs text-[#6B4C3B]">
              <button className="flex items-center gap-1 hover:text-[#C0392B] transition-colors">
                <Globe size={12} /> Bangladesh (BDT ৳)
              </button>
              <span className="text-[#C8A87E]">|</span>
              <button onClick={() => navigate('contact')} className="hover:text-[#C0392B] transition-colors">Help</button>
              {isLoggedIn ? (
                <span className="text-[#8B4513] font-medium">Hi, {user?.name.split(' ')[0]} ✦ {user?.points} pts</span>
              ) : (
                <button onClick={() => navigate('auth')} className="hover:text-[#C0392B] transition-colors">Sign In / Register</button>
              )}
            </div>
          </div>
        </div>

        {/* Main header */}
        <div className="max-w-7xl mx-auto px-4 lg:px-8 py-4 flex items-center justify-between gap-4">
          {/* Mobile menu toggle */}
          <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="lg:hidden text-[#3D2B1F]">
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>

          {/* Logo */}
          <button onClick={() => navigate('home')} className="flex items-center gap-2 flex-shrink-0">
            <div className="relative">
              <div className="w-10 h-10 bg-[#C0392B] rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-lg">আ</span>
              </div>
            </div>
            <div className="text-left">
              <div className="text-2xl font-bold text-[#2C1810] tracking-tight leading-none" style={{ fontFamily: 'Georgia, serif' }}>
                Aarong
              </div>
              <div className="text-[10px] tracking-[0.25em] text-[#8B4513] uppercase leading-none">আড়ং · Est. 1978</div>
            </div>
          </button>

          {/* Search bar - desktop */}
          <div className="hidden lg:flex flex-1 max-w-xl relative" ref={searchRef}>
            <div className="relative w-full">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-[#A07850]" size={18} />
              <input
                type="text"
                value={searchVal}
                onChange={e => handleSearch(e.target.value)}
                onFocus={() => searchVal.length > 1 && setShowSearch(true)}
                placeholder='Search "Jamdani Saree", "Nakshi Kantha"...'
                className="w-full pl-12 pr-12 py-3 bg-[#FAF7F2] border border-[#E8D5B0] rounded-full text-sm text-[#3D2B1F] placeholder-[#A07850] focus:outline-none focus:ring-2 focus:ring-[#C0392B]/30 focus:border-[#C0392B] transition-all"
              />
              <button className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-[#A07850] hover:text-[#C0392B] transition-colors">
                <Mic size={16} />
              </button>
            </div>
            {showSearch && searchResults.length > 0 && (
              <div className="absolute top-full mt-2 w-full bg-white rounded-2xl shadow-2xl border border-[#E8D5B0] z-50 overflow-hidden">
                <div className="p-2">
                  <p className="text-xs text-[#A07850] px-3 py-2 flex items-center gap-1">
                    <Sparkles size={12} /> AI-powered suggestions
                  </p>
                  {searchResults.map(p => (
                    <button key={p.id} onClick={() => { navigate('product', p.id); setShowSearch(false); setSearchVal(''); }}
                      className="w-full flex items-center gap-3 p-3 hover:bg-[#FAF7F2] rounded-xl transition-colors text-left">
                      <img src={p.images[0]} alt={p.name} className="w-10 h-10 rounded-lg object-cover" />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-[#3D2B1F]">{p.name}</p>
                        <p className="text-xs text-[#8B4513]">৳{p.price.toLocaleString()}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Action icons */}
          <div className="flex items-center gap-1 lg:gap-3">
            <button onClick={() => setIsSearchOpen(true)} className="lg:hidden p-2 text-[#3D2B1F] hover:text-[#C0392B] transition-colors">
              <Search size={22} />
            </button>
            <button
              onClick={() => navigate('account')}
              className="hidden lg:flex p-2 text-[#3D2B1F] hover:text-[#C0392B] transition-colors relative group items-center gap-1"
            >
              <User size={22} />
              {isLoggedIn && <div className="w-2 h-2 bg-[#27AE60] rounded-full absolute top-1 right-1" />}
            </button>
            <button
              onClick={() => setIsWishlistOpen(!isWishlistOpen)}
              className="p-2 text-[#3D2B1F] hover:text-[#C0392B] transition-colors relative"
            >
              <Heart size={22} className={wishlist.length > 0 ? 'fill-[#C0392B] text-[#C0392B]' : ''} />
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#C0392B] text-white text-[10px] rounded-full flex items-center justify-center font-bold">
                  {wishlist.length}
                </span>
              )}
            </button>
            <button
              onClick={() => setIsCartOpen(true)}
              className="p-2 text-[#3D2B1F] hover:text-[#C0392B] transition-colors relative"
            >
              <ShoppingBag size={22} />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#C0392B] text-white text-[10px] rounded-full flex items-center justify-center font-bold">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Navigation */}
        <nav className="hidden lg:block border-t border-[#E8D5B0] bg-white">
          <div className="max-w-7xl mx-auto px-8">
            <ul className="flex items-center justify-center gap-0">
              {categories.map(cat => (
                <li key={cat.id} className="relative group">
                  <button
                    onClick={() => navigate('category', cat.id)}
                    className="flex items-center gap-1 px-4 py-4 text-sm font-medium text-[#3D2B1F] hover:text-[#C0392B] transition-colors uppercase tracking-wide group-hover:text-[#C0392B]"
                  >
                    {cat.label}
                    {cat.subcategories.length > 0 && <ChevronDown size={12} className="group-hover:rotate-180 transition-transform duration-200" />}
                  </button>
                  {cat.subcategories.length > 0 && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#C0392B] scale-x-0 group-hover:scale-x-100 transition-transform duration-300" />
                  )}
                  {cat.subcategories.length > 0 && <MegaMenu category={cat} onNavigate={navigate} />}
                </li>
              ))}
            </ul>
          </div>
        </nav>

        {/* Mobile menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden bg-white border-t border-[#E8D5B0] overflow-y-auto max-h-screen">
            <div className="p-4">
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#A07850]" size={16} />
                <input
                  type="text"
                  placeholder="Search products..."
                  className="w-full pl-10 pr-4 py-2.5 bg-[#FAF7F2] border border-[#E8D5B0] rounded-full text-sm focus:outline-none"
                />
              </div>
              {categories.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => navigate('category', cat.id)}
                  className="block w-full text-left py-3 px-2 border-b border-[#F0E6D3] text-[#3D2B1F] font-medium"
                >
                  {cat.label}
                </button>
              ))}
              <div className="mt-4 flex flex-col gap-2">
                <button onClick={() => navigate('store-locator')} className="flex items-center gap-2 py-2 text-sm text-[#6B4C3B]"><MapPin size={14} /> Store Locator</button>
                <button onClick={() => navigate('account')} className="flex items-center gap-2 py-2 text-sm text-[#6B4C3B]"><User size={14} /> My Account</button>
                <button onClick={() => navigate('track-order')} className="flex items-center gap-2 py-2 text-sm text-[#6B4C3B]"><Bell size={14} /> Track Order</button>
              </div>
            </div>
          </div>
        )}
      </header>
    </>
  );
};

export default Header;
