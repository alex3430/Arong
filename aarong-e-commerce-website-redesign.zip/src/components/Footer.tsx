import React, { useState } from 'react';
import { ArrowRight, Mail, Phone, MapPin } from 'lucide-react';
import { useApp } from '../context/AppContext';

const Footer: React.FC = () => {
  const { setCurrentPage, setSelectedCategory } = useApp();
  const [email, setEmail] = useState('');
  const [subbed, setSubbed] = useState(false);

  return (
    <footer className="bg-[#1A0E09] text-[#C8A87E]">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-8 py-16 grid grid-cols-2 md:grid-cols-5 gap-8">
        {/* Brand */}
        <div className="col-span-2 md:col-span-1">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-10 h-10 bg-[#C0392B] rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-lg">আ</span>
            </div>
            <div>
              <div className="text-xl font-bold text-white" style={{ fontFamily: 'Georgia, serif' }}>Aarong</div>
              <div className="text-[10px] tracking-[0.2em] text-[#C8A87E]">আড়ং · EST. 1978</div>
            </div>
          </div>
          <p className="text-sm text-[#A07850] leading-relaxed mb-4">
            Bangladesh's most beloved lifestyle brand, celebrating authentic handcrafted artistry and empowering 65,000+ artisans since 1978.
          </p>
          <div className="text-xs text-[#6B4C3B]">
            <p>A BRAC Social Enterprise</p>
            <p className="mt-1">🌱 Committed to Sustainability</p>
          </div>

          {/* Social */}
          <div className="flex gap-2 mt-5">
            {['📷', '👥', '🐦', '▶️'].map((icon) => (
              <button key={icon} className="w-9 h-9 bg-white/5 hover:bg-[#C0392B] rounded-full flex items-center justify-center text-sm transition-all">
                {icon}
              </button>
            ))}
          </div>
        </div>

        {/* Shop */}
        <div>
          <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-4">Shop</h4>
          <ul className="space-y-2.5">
            {['Women', 'Men', 'Kids', 'Home Décor', 'Jewellery', 'Wedding', 'Gifts & Crafts', 'Beauty', 'New Arrivals', 'Sale'].map((item) => {
              const catMap: Record<string, string> = { Women: 'women', Men: 'men', Kids: 'kids', 'Home Décor': 'home-decor', Jewellery: 'jewellery', Wedding: 'wedding', 'Gifts & Crafts': 'gifts', Beauty: 'beauty', 'New Arrivals': 'new-arrivals', Sale: 'sale' };
              return (
                <li key={item}>
                  <button onClick={() => { setSelectedCategory(catMap[item] || item.toLowerCase()); setCurrentPage('category'); }}
                    className="text-sm text-[#A07850] hover:text-[#F5E6C8] transition-colors">
                    {item}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>

        {/* About */}
        <div>
          <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-4">About</h4>
          <ul className="space-y-2.5">
            {[
              { label: 'Our Story', page: 'about' },
              { label: 'Heritage & History', page: 'about' },
              { label: 'Artisan Partners', page: 'about' },
              { label: 'Sustainability', page: 'about' },
              { label: 'BRAC Connection', page: 'about' },
              { label: 'Careers', page: 'about' },
              { label: 'Press & Media', page: 'about' },
              { label: 'Store Locator', page: 'store-locator' },
            ].map(link => (
              <li key={link.label}>
                <button onClick={() => setCurrentPage(link.page)}
                  className="text-sm text-[#A07850] hover:text-[#F5E6C8] transition-colors">
                  {link.label}
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* Support */}
        <div>
          <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-4">Support</h4>
          <ul className="space-y-2.5">
            {[
              { label: 'Help Center', page: 'support' },
              { label: 'Track Order', page: 'account' },
              { label: 'Returns & Exchanges', page: 'support' },
              { label: 'Shipping Info', page: 'support' },
              { label: 'Size Guide', page: 'support' },
              { label: 'Care Guide', page: 'support' },
              { label: 'Privacy Policy', page: 'support' },
              { label: 'Terms & Conditions', page: 'support' },
            ].map(link => (
              <li key={link.label}>
                <button onClick={() => setCurrentPage(link.page)}
                  className="text-sm text-[#A07850] hover:text-[#F5E6C8] transition-colors">
                  {link.label}
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* Newsletter + Contact */}
        <div>
          <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-4">Stay Connected</h4>
          {!subbed ? (
            <div className="mb-5">
              <p className="text-xs text-[#A07850] mb-3">Get 10% off your first order + exclusive artisan stories</p>
              <div className="space-y-2">
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6B4C3B]" size={14} />
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    className="w-full pl-10 pr-3 py-2.5 bg-white/5 border border-white/10 rounded-xl text-sm text-white placeholder-[#6B4C3B] focus:outline-none focus:border-[#C0392B]" />
                </div>
                <button onClick={() => email && setSubbed(true)}
                  className="w-full py-2.5 bg-[#C0392B] text-white rounded-xl text-sm font-semibold hover:bg-[#A93226] transition-colors flex items-center justify-center gap-2">
                  Subscribe <ArrowRight size={14} />
                </button>
              </div>
            </div>
          ) : (
            <div className="mb-5 p-3 bg-white/5 rounded-xl border border-white/10">
              <p className="text-sm text-[#27AE60] font-medium">✓ You're subscribed!</p>
              <p className="text-xs text-[#A07850] mt-1">Check your email for the 10% discount code.</p>
            </div>
          )}

          <div className="space-y-3">
            <h4 className="text-white font-bold text-sm tracking-wider uppercase">Contact Us</h4>
            <div className="flex items-center gap-2 text-xs text-[#A07850]">
              <Phone size={13} className="text-[#C0392B]" /> +880 1600 000000
            </div>
            <div className="flex items-center gap-2 text-xs text-[#A07850]">
              <Mail size={13} className="text-[#C0392B]" /> support@aarong.com
            </div>
            <div className="flex items-start gap-2 text-xs text-[#A07850]">
              <MapPin size={13} className="text-[#C0392B] flex-shrink-0 mt-0.5" /> BRAC Centre, 75 Mohakhali, Dhaka 1212, Bangladesh
            </div>
          </div>
        </div>
      </div>

      {/* International */}
      <div className="border-t border-white/5 max-w-7xl mx-auto px-8 py-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div>
            <p className="text-xs font-bold text-[#C0392B] tracking-wider uppercase mb-2">🌍 International Shipping</p>
            <p className="text-xs text-[#6B4C3B]">We deliver to 30+ countries. Free international shipping on orders over $150 USD.</p>
          </div>
          <div className="flex gap-2 flex-wrap">
            {['🇺🇸 USA', '🇬🇧 UK', '🇨🇦 Canada', '🇦🇺 Australia', '🇦🇪 UAE', '🇸🇦 Saudi Arabia', '+24 more'].map(c => (
              <span key={c} className="px-3 py-1 bg-white/5 text-[#A07850] rounded-full text-xs">{c}</span>
            ))}
          </div>
        </div>
      </div>

      {/* Payment methods */}
      <div className="border-t border-white/5 max-w-7xl mx-auto px-8 py-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-[#6B4C3B]">
            <span>🔐 256-bit SSL Secure</span>
            <span>·</span>
            <span>Payments powered by SSLCommerz</span>
          </div>
          <div className="flex items-center gap-2">
            {['VISA', 'MC', 'AMEX', 'bKash', 'Nagad', 'Rocket', 'COD'].map(p => (
              <span key={p} className="px-2 py-1 bg-white/5 text-[#A07850] text-[10px] font-bold rounded border border-white/10">{p}</span>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/5 bg-black/20">
        <div className="max-w-7xl mx-auto px-8 py-4 flex flex-col md:flex-row items-center justify-between gap-2 text-xs text-[#6B4C3B]">
          <p>© 2024 Aarong | আড়ং. All rights reserved. A BRAC Social Enterprise.</p>
          <p>Designed with ♥ for Bangladesh's artisan community</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
