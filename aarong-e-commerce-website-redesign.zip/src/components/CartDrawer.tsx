import React, { useState } from 'react';
import { X, Plus, Minus, ShoppingBag, Tag, Truck, Gift, ArrowRight, Trash2 } from 'lucide-react';
import { useApp } from '../context/AppContext';

const CartDrawer: React.FC = () => {
  const { isCartOpen, setIsCartOpen, cart, removeFromCart, updateQuantity, cartTotal, discount, appliedCoupon, setAppliedCoupon, setCurrentPage } = useApp();
  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState('');

  const validCoupons = ['AARONG10', 'EID2024', 'WELCOME20'];
  const discountAmount = cartTotal * discount;
  const shipping = cartTotal > 3000 ? 0 : 120;
  const finalTotal = cartTotal - discountAmount + shipping;

  const applyCoupon = () => {
    if (validCoupons.includes(couponInput.toUpperCase())) {
      setAppliedCoupon(couponInput.toUpperCase());
      setCouponError('');
    } else {
      setCouponError('Invalid coupon code. Try AARONG10 or EID2024');
    }
  };

  return (
    <>
      {/* Overlay */}
      <div
        className={`fixed inset-0 bg-black/50 backdrop-blur-sm z-50 transition-opacity duration-300 ${isCartOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={() => setIsCartOpen(false)}
      />
      {/* Drawer */}
      <div className={`fixed right-0 top-0 h-full w-full sm:w-[420px] bg-white z-50 shadow-2xl flex flex-col transform transition-transform duration-400 ease-out ${isCartOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#E8D5B0] bg-[#FAF7F2]">
          <div className="flex items-center gap-3">
            <ShoppingBag className="text-[#C0392B]" size={22} />
            <div>
              <h2 className="font-semibold text-[#2C1810] text-lg" style={{ fontFamily: 'Georgia, serif' }}>Shopping Bag</h2>
              <p className="text-xs text-[#8B4513]">{cart.length} item{cart.length !== 1 ? 's' : ''}</p>
            </div>
          </div>
          <button onClick={() => setIsCartOpen(false)} className="p-2 text-[#6B4C3B] hover:text-[#C0392B] hover:bg-[#F0E6D3] rounded-full transition-all">
            <X size={20} />
          </button>
        </div>

        {/* Free shipping progress */}
        {cartTotal < 3000 && (
          <div className="px-6 py-3 bg-[#FFF8F0] border-b border-[#E8D5B0]">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs text-[#6B4C3B] flex items-center gap-1"><Truck size={12} /> Add ৳{(3000 - cartTotal).toLocaleString()} more for free shipping</span>
              <span className="text-xs font-semibold text-[#C0392B]">{Math.round((cartTotal / 3000) * 100)}%</span>
            </div>
            <div className="h-1.5 bg-[#E8D5B0] rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-[#C0392B] to-[#E74C3C] rounded-full transition-all duration-500" style={{ width: `${Math.min((cartTotal / 3000) * 100, 100)}%` }} />
            </div>
          </div>
        )}
        {cartTotal >= 3000 && (
          <div className="px-6 py-2 bg-[#E8F5E9] border-b border-[#C8E6C9]">
            <p className="text-xs text-[#2E7D32] font-medium flex items-center gap-1"><Truck size={12} /> 🎉 You qualify for FREE shipping!</p>
          </div>
        )}

        {/* Cart Items */}
        <div className="flex-1 overflow-y-auto px-6 py-4">
          {cart.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center gap-4">
              <div className="w-24 h-24 bg-[#F0E6D3] rounded-full flex items-center justify-center">
                <ShoppingBag className="text-[#C8A87E]" size={36} />
              </div>
              <h3 className="font-semibold text-[#3D2B1F]" style={{ fontFamily: 'Georgia, serif' }}>Your bag is empty</h3>
              <p className="text-sm text-[#8B4513]">Discover our handcrafted collection</p>
              <button
                onClick={() => { setIsCartOpen(false); setCurrentPage('category'); }}
                className="px-6 py-3 bg-[#C0392B] text-white rounded-full text-sm font-medium hover:bg-[#A93226] transition-colors"
              >
                Start Shopping
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {cart.map(item => (
                <div key={`${item.id}-${item.selectedColor}-${item.selectedSize}`} className="flex gap-3 p-3 bg-[#FAF7F2] rounded-xl border border-[#E8D5B0]">
                  <div className="w-20 h-20 rounded-lg overflow-hidden bg-white flex-shrink-0">
                    <img src={item.images[0]} alt={item.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="text-sm font-medium text-[#2C1810] line-clamp-1">{item.name}</p>
                        <p className="text-xs text-[#8B4513] mt-0.5">{item.selectedColor} · {item.selectedSize}</p>
                      </div>
                      <button onClick={() => removeFromCart(item.id, item.selectedColor, item.selectedSize)} className="text-[#C0392B] hover:text-[#A93226] transition-colors flex-shrink-0">
                        <Trash2 size={14} />
                      </button>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-2 bg-white rounded-full border border-[#E8D5B0] px-2 py-1">
                        <button onClick={() => updateQuantity(item.id, item.selectedColor, item.selectedSize, item.quantity - 1)} className="text-[#6B4C3B] hover:text-[#C0392B] transition-colors">
                          <Minus size={12} />
                        </button>
                        <span className="text-sm font-semibold text-[#2C1810] w-4 text-center">{item.quantity}</span>
                        <button onClick={() => updateQuantity(item.id, item.selectedColor, item.selectedSize, item.quantity + 1)} className="text-[#6B4C3B] hover:text-[#C0392B] transition-colors">
                          <Plus size={12} />
                        </button>
                      </div>
                      <p className="text-sm font-bold text-[#C0392B]">৳{(item.price * item.quantity).toLocaleString()}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {cart.length > 0 && (
          <div className="border-t border-[#E8D5B0] bg-[#FAF7F2] px-6 py-5">
            {/* Coupon */}
            <div className="mb-4">
              {!appliedCoupon ? (
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="absolute left-3 top-1/2 -translate-y-1/2 text-[#A07850]" size={14} />
                    <input
                      type="text"
                      value={couponInput}
                      onChange={e => setCouponInput(e.target.value)}
                      placeholder="Coupon code (e.g. EID2024)"
                      className="w-full pl-9 pr-3 py-2.5 bg-white border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B] transition-colors"
                    />
                  </div>
                  <button onClick={applyCoupon} className="px-4 py-2.5 bg-[#2C1810] text-white rounded-xl text-sm font-medium hover:bg-[#C0392B] transition-colors">
                    Apply
                  </button>
                </div>
              ) : (
                <div className="flex items-center justify-between bg-[#E8F5E9] px-3 py-2 rounded-xl">
                  <span className="text-sm text-[#2E7D32] font-medium flex items-center gap-1"><Gift size={14} /> {appliedCoupon} applied!</span>
                  <button onClick={() => setAppliedCoupon('')} className="text-xs text-[#C0392B] hover:underline">Remove</button>
                </div>
              )}
              {couponError && <p className="text-xs text-[#C0392B] mt-1">{couponError}</p>}
            </div>

            {/* Price Summary */}
            <div className="space-y-2 mb-4">
              <div className="flex justify-between text-sm">
                <span className="text-[#6B4C3B]">Subtotal</span>
                <span className="text-[#2C1810] font-medium">৳{cartTotal.toLocaleString()}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-[#27AE60]">Discount ({(discount * 100).toFixed(0)}%)</span>
                  <span className="text-[#27AE60] font-medium">-৳{discountAmount.toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between text-sm">
                <span className="text-[#6B4C3B]">Shipping</span>
                <span className={shipping === 0 ? 'text-[#27AE60] font-medium' : 'text-[#2C1810] font-medium'}>
                  {shipping === 0 ? 'FREE' : `৳${shipping}`}
                </span>
              </div>
              <div className="flex justify-between font-bold text-base border-t border-[#E8D5B0] pt-2 mt-2">
                <span className="text-[#2C1810]">Total</span>
                <span className="text-[#C0392B]">৳{finalTotal.toLocaleString()}</span>
              </div>
            </div>

            <button
              onClick={() => { setIsCartOpen(false); setCurrentPage('checkout'); }}
              className="w-full py-4 bg-[#C0392B] text-white rounded-full font-semibold flex items-center justify-center gap-2 hover:bg-[#A93226] active:scale-[0.98] transition-all text-sm"
            >
              Proceed to Checkout <ArrowRight size={16} />
            </button>
            <button
              onClick={() => setIsCartOpen(false)}
              className="w-full py-2 text-[#6B4C3B] text-sm mt-2 hover:text-[#C0392B] transition-colors"
            >
              Continue Shopping
            </button>
          </div>
        )}
      </div>
    </>
  );
};

export default CartDrawer;
