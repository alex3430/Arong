import React from 'react';
import { CheckCircle, XCircle, Info } from 'lucide-react';
import { useApp } from '../context/AppContext';

const Notification: React.FC = () => {
  const { notification } = useApp();

  if (!notification) return null;

  const icons = {
    success: <CheckCircle size={18} className="text-[#27AE60]" />,
    error: <XCircle size={18} className="text-[#C0392B]" />,
    info: <Info size={18} className="text-[#2980B9]" />,
  };

  const colors = {
    success: 'border-l-4 border-[#27AE60] bg-[#E8F5E9]',
    error: 'border-l-4 border-[#C0392B] bg-[#FDECEA]',
    info: 'border-l-4 border-[#2980B9] bg-[#EBF4FB]',
  };

  return (
    <div className={`fixed bottom-6 left-1/2 -translate-x-1/2 z-[100] flex items-center gap-3 px-5 py-3.5 rounded-2xl shadow-2xl ${colors[notification.type]} animate-slide-up min-w-[280px] max-w-[400px]`}>
      {icons[notification.type]}
      <p className="text-sm font-medium text-[#2C1810] flex-1">{notification.message}</p>
    </div>
  );
};

export default Notification;
