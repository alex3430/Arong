import React, { useState } from 'react';
import { Sparkles, ArrowRight, RefreshCw, ShoppingBag, Heart, Star } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { products } from '../data/products';

const occasions = ['Eid Celebration', 'Wedding Guest', 'Office Wear', 'Casual Day Out', 'Bridal', 'Festive', 'Date Night', 'Cultural Event'];
const preferences = ['Traditional', 'Fusion', 'Minimalist', 'Bold & Vibrant', 'Earthy Tones', 'Pastels'];
const budgets = ['Under ৳2,000', '৳2,000 - ৳5,000', '৳5,000 - ৳10,000', 'Above ৳10,000'];

const AIStylistPage: React.FC = () => {
  const { setCurrentPage, addToCart, toggleWishlist, isWishlisted, setSelectedProduct } = useApp();
  const [step, setStep] = useState(1);
  const [selectedOccasion, setSelectedOccasion] = useState('');
  const [selectedStyle, setSelectedStyle] = useState('');
  const [selectedBudget, setSelectedBudget] = useState('');
  const [generating, setGenerating] = useState(false);
  const [recommendations, setRecommendations] = useState<typeof products>([]);
  const [aiMessage, setAiMessage] = useState('');

  const generateRecommendations = () => {
    setGenerating(true);
    setTimeout(() => {
      const recs = products.filter(p => p.isFeatured || p.isTrending).slice(0, 4);
      setRecommendations(recs);
      setAiMessage(`Based on your preference for **${selectedOccasion}** with a **${selectedStyle}** aesthetic and budget of **${selectedBudget}**, I've curated ${recs.length} perfect pieces that embody authentic Bangladeshi artistry. These handcrafted selections are trending this season and align perfectly with your style profile.`);
      setGenerating(false);
      setStep(4);
    }, 2500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAF7F2] via-white to-[#F0E6D3]">
      {/* Hero */}
      <div className="bg-gradient-to-r from-[#2C1810] via-[#4A2518] to-[#8B4513] py-16 px-8 text-center relative overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 30% 50%, #C0392B 0%, transparent 60%), radial-gradient(circle at 70% 50%, #F39C12 0%, transparent 60%)' }} />
        <div className="relative">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 px-4 py-2 rounded-full text-[#F5E6C8] text-xs font-semibold mb-6">
            <Sparkles size={14} /> AI-Powered Personal Stylist
          </div>
          <h1 className="text-4xl md:text-5xl font-light text-white mb-4" style={{ fontFamily: 'Georgia, serif' }}>
            Your Personal<br /><span className="font-bold italic">Aarong Stylist</span>
          </h1>
          <p className="text-white/70 max-w-lg mx-auto">
            Tell us about your occasion and style, and our AI will curate the perfect Bangladeshi artisan pieces just for you.
          </p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-12">
        {/* Progress */}
        {step < 4 && (
          <div className="flex items-center justify-center gap-3 mb-10">
            {[1, 2, 3].map(s => (
              <React.Fragment key={s}>
                <div className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold transition-all ${s <= step ? 'bg-[#C0392B] text-white' : 'bg-[#E8D5B0] text-[#A07850]'}`}>
                  {s < step ? '✓' : s}
                </div>
                {s < 3 && <div className={`flex-1 max-w-[60px] h-0.5 ${s < step ? 'bg-[#C0392B]' : 'bg-[#E8D5B0]'}`} />}
              </React.Fragment>
            ))}
          </div>
        )}

        {/* Step 1: Occasion */}
        {step === 1 && (
          <div className="bg-white rounded-3xl p-8 shadow-xl border border-[#E8D5B0]">
            <h2 className="text-2xl font-bold text-[#2C1810] mb-2" style={{ fontFamily: 'Georgia, serif' }}>What's the Occasion?</h2>
            <p className="text-[#8B4513] mb-6">Tell us what you're dressing for</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {occasions.map(occ => (
                <button key={occ} onClick={() => setSelectedOccasion(occ)}
                  className={`p-4 rounded-2xl border-2 text-sm font-medium transition-all ${selectedOccasion === occ ? 'border-[#C0392B] bg-[#FEF5F3] text-[#C0392B]' : 'border-[#E8D5B0] text-[#3D2B1F] hover:border-[#C0392B]/50'}`}>
                  {occ}
                </button>
              ))}
            </div>
            <button disabled={!selectedOccasion} onClick={() => setStep(2)}
              className="mt-8 w-full py-4 bg-[#C0392B] text-white rounded-full font-semibold disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#A93226] transition-colors flex items-center justify-center gap-2">
              Continue <ArrowRight size={18} />
            </button>
          </div>
        )}

        {/* Step 2: Style */}
        {step === 2 && (
          <div className="bg-white rounded-3xl p-8 shadow-xl border border-[#E8D5B0]">
            <h2 className="text-2xl font-bold text-[#2C1810] mb-2" style={{ fontFamily: 'Georgia, serif' }}>Your Style Preference</h2>
            <p className="text-[#8B4513] mb-6">How would you describe your aesthetic?</p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {preferences.map(pref => (
                <button key={pref} onClick={() => setSelectedStyle(pref)}
                  className={`p-4 rounded-2xl border-2 text-sm font-medium transition-all ${selectedStyle === pref ? 'border-[#C0392B] bg-[#FEF5F3] text-[#C0392B]' : 'border-[#E8D5B0] text-[#3D2B1F] hover:border-[#C0392B]/50'}`}>
                  {pref}
                </button>
              ))}
            </div>
            <div className="flex gap-3 mt-8">
              <button onClick={() => setStep(1)} className="px-6 py-4 border border-[#E8D5B0] rounded-full font-semibold text-[#6B4C3B] hover:border-[#C0392B] transition-colors">
                ← Back
              </button>
              <button disabled={!selectedStyle} onClick={() => setStep(3)}
                className="flex-1 py-4 bg-[#C0392B] text-white rounded-full font-semibold disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#A93226] transition-colors flex items-center justify-center gap-2">
                Continue <ArrowRight size={18} />
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Budget */}
        {step === 3 && (
          <div className="bg-white rounded-3xl p-8 shadow-xl border border-[#E8D5B0]">
            <h2 className="text-2xl font-bold text-[#2C1810] mb-2" style={{ fontFamily: 'Georgia, serif' }}>What's Your Budget?</h2>
            <p className="text-[#8B4513] mb-6">We'll find the best artisan pieces within your range</p>
            <div className="grid grid-cols-2 gap-4">
              {budgets.map(budget => (
                <button key={budget} onClick={() => setSelectedBudget(budget)}
                  className={`p-5 rounded-2xl border-2 text-sm font-semibold transition-all ${selectedBudget === budget ? 'border-[#C0392B] bg-[#FEF5F3] text-[#C0392B]' : 'border-[#E8D5B0] text-[#3D2B1F] hover:border-[#C0392B]/50'}`}>
                  {budget}
                </button>
              ))}
            </div>
            <div className="flex gap-3 mt-8">
              <button onClick={() => setStep(2)} className="px-6 py-4 border border-[#E8D5B0] rounded-full font-semibold text-[#6B4C3B] hover:border-[#C0392B] transition-colors">
                ← Back
              </button>
              <button disabled={!selectedBudget} onClick={generateRecommendations}
                className="flex-1 py-4 bg-gradient-to-r from-[#C0392B] to-[#8B4513] text-white rounded-full font-semibold disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg transition-all flex items-center justify-center gap-2">
                <Sparkles size={18} /> Generate My Style
              </button>
            </div>
          </div>
        )}

        {/* Generating */}
        {generating && (
          <div className="bg-white rounded-3xl p-12 shadow-xl border border-[#E8D5B0] text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-[#C0392B] to-[#8B4513] rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
              <Sparkles className="text-white" size={36} />
            </div>
            <h3 className="text-xl font-bold text-[#2C1810] mb-2" style={{ fontFamily: 'Georgia, serif' }}>Creating Your Style Profile...</h3>
            <p className="text-[#8B4513]">Our AI is analyzing 65,000+ artisan products to find your perfect match</p>
            <div className="mt-6 flex justify-center gap-1">
              {[0, 1, 2].map(i => (
                <div key={i} className="w-2 h-2 bg-[#C0392B] rounded-full animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
              ))}
            </div>
          </div>
        )}

        {/* Results */}
        {step === 4 && recommendations.length > 0 && (
          <div>
            {/* AI Message */}
            <div className="bg-white rounded-3xl p-6 shadow-xl border border-[#E8D5B0] mb-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-[#C0392B] to-[#8B4513] rounded-full flex items-center justify-center flex-shrink-0">
                  <Sparkles className="text-white" size={22} />
                </div>
                <div>
                  <p className="font-bold text-[#2C1810] mb-1">Aarong AI Stylist</p>
                  <p className="text-sm text-[#6B4C3B] leading-relaxed">{aiMessage}</p>
                </div>
              </div>
            </div>

            {/* Your Style Summary */}
            <div className="flex gap-3 mb-6 flex-wrap">
              <span className="px-4 py-2 bg-[#C0392B]/10 text-[#C0392B] rounded-full text-sm font-semibold">📅 {selectedOccasion}</span>
              <span className="px-4 py-2 bg-[#2C1810]/10 text-[#2C1810] rounded-full text-sm font-semibold">✨ {selectedStyle}</span>
              <span className="px-4 py-2 bg-[#27AE60]/10 text-[#27AE60] rounded-full text-sm font-semibold">💰 {selectedBudget}</span>
            </div>

            <h2 className="text-2xl font-bold text-[#2C1810] mb-6" style={{ fontFamily: 'Georgia, serif' }}>Your Curated Collection</h2>

            <div className="grid grid-cols-2 gap-4">
              {recommendations.map(product => {
                const wishlisted = isWishlisted(product.id);
                return (
                  <div key={product.id} className="bg-white rounded-2xl overflow-hidden border border-[#E8D5B0] hover:shadow-lg transition-all">
                    <div className="relative aspect-square bg-[#F9F3EA] cursor-pointer" onClick={() => { setSelectedProduct(product); setCurrentPage('product'); }}>
                      <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                      <div className="absolute top-3 right-3">
                        <span className="px-2 py-1 bg-[#Sparkles]/10 bg-white/90 text-[#C0392B] text-[10px] font-bold rounded-full flex items-center gap-1">
                          <Sparkles size={9} /> AI Pick
                        </span>
                      </div>
                      <button onClick={e => { e.stopPropagation(); toggleWishlist(product); }}
                        className={`absolute top-3 left-3 w-9 h-9 rounded-full flex items-center justify-center shadow-md transition-all ${wishlisted ? 'bg-[#C0392B] text-white' : 'bg-white text-[#3D2B1F] hover:bg-[#C0392B] hover:text-white'}`}>
                        <Heart size={15} className={wishlisted ? 'fill-current' : ''} />
                      </button>
                    </div>
                    <div className="p-4">
                      <p className="text-xs text-[#A07850] uppercase tracking-widest mb-1">{product.subcategory}</p>
                      <h3 className="text-sm font-semibold text-[#2C1810] line-clamp-2 mb-2">{product.name}</h3>
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-bold text-[#C0392B]">৳{product.price.toLocaleString()}</span>
                        <div className="flex items-center gap-1">
                          <Star size={12} className="text-[#F39C12] fill-[#F39C12]" />
                          <span className="text-xs text-[#6B4C3B]">{product.rating}</span>
                        </div>
                      </div>
                      <button onClick={() => addToCart(product, product.colors[0], product.sizes[0])}
                        className="w-full py-2.5 bg-[#2C1810] text-white rounded-full text-xs font-semibold hover:bg-[#C0392B] transition-colors flex items-center justify-center gap-1">
                        <ShoppingBag size={13} /> Add to Bag
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-6 flex gap-3">
              <button onClick={() => { setStep(1); setSelectedOccasion(''); setSelectedStyle(''); setSelectedBudget(''); setRecommendations([]); }}
                className="flex-1 py-4 border border-[#E8D5B0] rounded-full font-semibold text-[#3D2B1F] hover:border-[#C0392B] transition-colors flex items-center justify-center gap-2">
                <RefreshCw size={16} /> Start Over
              </button>
              <button onClick={() => setCurrentPage('category')}
                className="flex-1 py-4 bg-[#C0392B] text-white rounded-full font-semibold hover:bg-[#A93226] transition-colors flex items-center justify-center gap-2">
                Browse More <ArrowRight size={16} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AIStylistPage;
