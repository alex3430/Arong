import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Phone, Mail, MessageCircle, Package, RotateCcw, Truck, CreditCard, Search } from 'lucide-react';
import { useApp } from '../context/AppContext';

const faqs = [
  { q: 'What is Aarong\'s return policy?', a: 'We offer 7-day hassle-free returns on all products. Items must be in original condition with tags attached. Contact us via email or visit any Aarong store. For online orders, initiate the return from "My Account" → "Orders".' },
  { q: 'How long does delivery take?', a: 'Standard delivery: 3-5 business days across Bangladesh. Express delivery: 1-2 business days. Same-day delivery is available in Dhaka (orders placed before 12 PM). International delivery: 7-14 business days.' },
  { q: 'Is Cash on Delivery (COD) available?', a: 'Yes! COD is available for orders up to ৳20,000 across Bangladesh. For orders above this amount, we recommend card payment or mobile banking.' },
  { q: 'How do I track my order?', a: 'You\'ll receive an SMS and email with a tracking link once your order is shipped. You can also track from "My Account" → "Orders" → "Track Order".' },
  { q: 'Are all Aarong products handmade?', a: 'Yes! Every Aarong product is handcrafted by verified artisans from across Bangladesh. We have 65,000+ artisan partners who create our authentic ethnic clothing, home décor, and crafts.' },
  { q: 'Can I exchange a product?', a: 'Yes, exchanges are available within 7 days of purchase at any Aarong store. For online orders, contact our customer service to arrange an exchange.' },
  { q: 'What payment methods are accepted?', a: 'We accept Visa, Mastercard, American Express, bKash, Nagad, Rocket, SureCash, internet banking, and Cash on Delivery.' },
  { q: 'Do you ship internationally?', a: 'Yes! We ship to 30+ countries including USA, UK, Canada, Australia, and UAE. International shipping charges and delivery times vary by destination.' },
  { q: 'How does the loyalty points system work?', a: 'Earn 10 points for every ৳100 spent. Points can be redeemed at ৳1 per 10 points. Additional points for reviews (+50), referrals (+200), and birthday bonuses (+500).' },
  { q: 'How do I care for my Aarong products?', a: 'Care instructions are provided on each product page and on the product label. Generally, handcrafted items require gentle hand washing or dry cleaning. Specific instructions vary by material.' },
];

const SupportPage: React.FC = () => {
  const { setCurrentPage } = useApp();
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchFaq, setSearchFaq] = useState('');
  const [contactForm, setContactForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const categories = [
    { id: 'all', label: 'All', icon: <MessageCircle size={16} /> },
    { id: 'orders', label: 'Orders', icon: <Package size={16} /> },
    { id: 'returns', label: 'Returns', icon: <RotateCcw size={16} /> },
    { id: 'delivery', label: 'Delivery', icon: <Truck size={16} /> },
    { id: 'payment', label: 'Payment', icon: <CreditCard size={16} /> },
  ];

  const filteredFaqs = faqs.filter(f => searchFaq ? f.q.toLowerCase().includes(searchFaq.toLowerCase()) : true);

  return (
    <div className="min-h-screen bg-[#FAF7F2]">
      {/* Hero */}
      <div className="bg-gradient-to-r from-[#2C1810] to-[#8B4513] py-16 px-8 text-center text-white">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-light mb-4" style={{ fontFamily: 'Georgia, serif' }}>How Can We Help You?</h1>
          <p className="text-white/70 mb-8">Our artisan-hearted team is always here for you</p>
          <div className="relative max-w-lg mx-auto">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-white/40" size={18} />
            <input type="text" placeholder="Search for help..." value={searchFaq} onChange={e => setSearchFaq(e.target.value)}
              className="w-full pl-14 pr-6 py-4 bg-white/10 border border-white/20 text-white placeholder-white/40 rounded-full focus:outline-none focus:border-white/60 backdrop-blur-sm" />
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 md:px-8 py-12">
        {/* Quick Help */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {[
            { icon: '📦', title: 'Track Order', desc: 'Check your order status', action: () => setCurrentPage('account') },
            { icon: '↩️', title: 'Returns', desc: 'Start a return request', action: () => {} },
            { icon: '💬', title: 'Live Chat', desc: 'Chat with our team', action: () => {} },
            { icon: '📞', title: 'Call Us', desc: '+880 1600 000000', action: () => {} },
          ].map((item, i) => (
            <button key={i} onClick={item.action}
              className="bg-white rounded-2xl p-5 border border-[#E8D5B0] hover:border-[#C0392B]/40 hover:shadow-md transition-all group text-center">
              <div className="text-3xl mb-3">{item.icon}</div>
              <h3 className="font-bold text-[#2C1810] text-sm group-hover:text-[#C0392B] transition-colors">{item.title}</h3>
              <p className="text-xs text-[#8B4513] mt-1">{item.desc}</p>
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* FAQ */}
          <div className="md:col-span-2">
            <h2 className="text-2xl font-bold text-[#2C1810] mb-6" style={{ fontFamily: 'Georgia, serif' }}>Frequently Asked Questions</h2>

            <div className="flex gap-2 flex-wrap mb-6">
              {categories.map(cat => (
                <button key={cat.id} onClick={() => setActiveCategory(cat.id)}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-semibold transition-all ${activeCategory === cat.id ? 'bg-[#C0392B] text-white' : 'bg-white border border-[#E8D5B0] text-[#3D2B1F] hover:border-[#C0392B]'}`}>
                  {cat.icon} {cat.label}
                </button>
              ))}
            </div>

            <div className="space-y-3">
              {filteredFaqs.map((faq, i) => (
                <div key={i} className="bg-white rounded-2xl border border-[#E8D5B0] overflow-hidden">
                  <button className="w-full flex items-center justify-between px-5 py-4 text-left" onClick={() => setOpenFaq(openFaq === i ? null : i)}>
                    <span className="font-semibold text-[#2C1810] text-sm pr-4">{faq.q}</span>
                    {openFaq === i ? <ChevronUp className="text-[#C0392B] flex-shrink-0" size={18} /> : <ChevronDown className="text-[#A07850] flex-shrink-0" size={18} />}
                  </button>
                  {openFaq === i && (
                    <div className="px-5 pb-4">
                      <p className="text-sm text-[#6B4C3B] leading-relaxed border-t border-[#E8D5B0] pt-3">{faq.a}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Policies */}
            <div className="mt-10 grid grid-cols-2 gap-4">
              {[
                { title: 'Return & Refund Policy', icon: '↩️', desc: '7-day returns, 14-day refund processing' },
                { title: 'Shipping Information', icon: '🚚', desc: 'Nationwide delivery, express options available' },
                { title: 'Privacy Policy', icon: '🔐', desc: 'How we protect your data' },
                { title: 'Terms & Conditions', icon: '📋', desc: 'Our service terms and user agreement' },
              ].map((p, i) => (
                <button key={i} className="text-left p-4 bg-white border border-[#E8D5B0] rounded-xl hover:border-[#C0392B]/40 transition-all">
                  <div className="text-2xl mb-2">{p.icon}</div>
                  <h4 className="font-semibold text-[#2C1810] text-sm">{p.title}</h4>
                  <p className="text-xs text-[#8B4513] mt-1">{p.desc}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Contact Form */}
          <div>
            <div className="bg-white rounded-2xl p-6 border border-[#E8D5B0] shadow-sm sticky top-4">
              <h3 className="font-bold text-[#2C1810] text-lg mb-5" style={{ fontFamily: 'Georgia, serif' }}>Still Need Help?</h3>

              {!submitted ? (
                <form onSubmit={e => { e.preventDefault(); setSubmitted(true); }} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">Name</label>
                    <input type="text" required placeholder="Your name" value={contactForm.name} onChange={e => setContactForm({ ...contactForm, name: e.target.value })}
                      className="w-full px-4 py-2.5 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B]" />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">Email</label>
                    <input type="email" required placeholder="your@email.com" value={contactForm.email} onChange={e => setContactForm({ ...contactForm, email: e.target.value })}
                      className="w-full px-4 py-2.5 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B]" />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">Subject</label>
                    <select value={contactForm.subject} onChange={e => setContactForm({ ...contactForm, subject: e.target.value })}
                      className="w-full px-4 py-2.5 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B]">
                      <option value="">Select a topic</option>
                      <option>Order Issue</option>
                      <option>Return/Refund</option>
                      <option>Product Inquiry</option>
                      <option>Payment Issue</option>
                      <option>Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">Message</label>
                    <textarea required rows={4} placeholder="Describe your issue..." value={contactForm.message} onChange={e => setContactForm({ ...contactForm, message: e.target.value })}
                      className="w-full px-4 py-2.5 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B] resize-none" />
                  </div>
                  <button type="submit" className="w-full py-3 bg-[#C0392B] text-white rounded-full font-semibold hover:bg-[#A93226] transition-colors">
                    Send Message
                  </button>
                </form>
              ) : (
                <div className="text-center py-6">
                  <div className="text-4xl mb-3">✅</div>
                  <h4 className="font-bold text-[#2C1810] mb-2">Message Sent!</h4>
                  <p className="text-sm text-[#6B4C3B]">We'll get back to you within 24 hours.</p>
                  <button onClick={() => setSubmitted(false)} className="mt-4 text-sm text-[#C0392B] hover:underline">Send another message</button>
                </div>
              )}

              {/* Contact info */}
              <div className="mt-6 pt-5 border-t border-[#E8D5B0] space-y-3">
                {[
                  { icon: <Phone size={14} className="text-[#C0392B]" />, label: '+880 1600 000000', sub: 'Sat-Thu 9AM-9PM' },
                  { icon: <Mail size={14} className="text-[#C0392B]" />, label: 'support@aarong.com', sub: 'Response within 24hrs' },
                ].map((c, i) => (
                  <div key={i} className="flex items-center gap-3">
                    {c.icon}
                    <div>
                      <p className="text-sm font-medium text-[#2C1810]">{c.label}</p>
                      <p className="text-xs text-[#8B4513]">{c.sub}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SupportPage;
