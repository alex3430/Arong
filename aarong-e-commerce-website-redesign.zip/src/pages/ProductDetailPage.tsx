import React, { useState } from 'react';
import {
  Star, Heart, ShoppingBag, ChevronLeft, ChevronRight, ZoomIn,
  Truck, Shield, RotateCcw, Share2, Plus, Minus, Check, Info,
  Package, Award, Sparkles
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { products } from '../data/products';
import { ProductCard } from './HomePage';

const reviews = [
  { name: 'Nadia Islam', date: 'Dec 2024', rating: 5, comment: 'Absolutely stunning saree! The quality is exceptional — exactly as described. The Nakshi Kantha embroidery is so intricate. Received so many compliments at my sister\'s wedding. Aarong never disappoints!', verified: true, helpful: 42 },
  { name: 'Farhan Ahmed', date: 'Nov 2024', rating: 5, comment: 'Bought this as a gift for my wife. She was overjoyed! The packaging was exquisite — felt like a luxury gift box. The fabric quality is superb. Will definitely order again.', verified: true, helpful: 28 },
  { name: 'Riya Chowdhury', date: 'Oct 2024', rating: 4, comment: 'Beautiful product, very authentic craftsmanship. The colors are exactly as shown. Only reason for 4 stars is that delivery took slightly longer than expected, but the product itself is 5 stars.', verified: true, helpful: 15 },
];

const ProductDetailPage: React.FC = () => {
  const { selectedProduct, addToCart, toggleWishlist, isWishlisted, setCurrentPage, setSelectedProduct } = useApp();
  const [currentImage, setCurrentImage] = useState(0);
  const [selectedColor, setSelectedColor] = useState(selectedProduct?.colors[0] || '');
  const [selectedSize, setSelectedSize] = useState(selectedProduct?.sizes[0] || '');
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'description' | 'material' | 'care' | 'reviews'>('description');
  const [isZoomed, setIsZoomed] = useState(false);
  const [zoomPos, setZoomPos] = useState({ x: 0, y: 0 });

  const [showAiExplain, setShowAiExplain] = useState(false);
  const [pincode, setPincode] = useState('');
  const [deliveryInfo, setDeliveryInfo] = useState('');

  if (!selectedProduct) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-[#8B4513] mb-4">Product not found</p>
          <button onClick={() => setCurrentPage('home')} className="px-6 py-3 bg-[#C0392B] text-white rounded-full text-sm">Go Home</button>
        </div>
      </div>
    );
  }

  const product = selectedProduct;
  const wishlisted = isWishlisted(product.id);
  const discount = product.originalPrice ? Math.round((1 - product.price / product.originalPrice) * 100) : 0;
  const related = products.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4);

  const allImages = product.images.length > 1 ? product.images : [
    product.images[0],
    'https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=600&q=80',
    'https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?w=600&q=80',
  ];

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setZoomPos({
      x: ((e.clientX - rect.left) / rect.width) * 100,
      y: ((e.clientY - rect.top) / rect.height) * 100,
    });
  };

  const checkDelivery = () => {
    if (pincode.length >= 4) {
      setDeliveryInfo(`✓ Delivery available to ${pincode} in 3-5 business days. Express delivery in 1-2 days at extra cost.`);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Breadcrumb */}
      <div className="bg-[#FAF7F2] border-b border-[#E8D5B0] px-4 md:px-8 py-3">
        <div className="max-w-7xl mx-auto flex items-center gap-2 text-sm text-[#8B4513]">
          <button onClick={() => setCurrentPage('home')} className="hover:text-[#C0392B] transition-colors">Home</button>
          <span>/</span>
          <button onClick={() => setCurrentPage('category')} className="hover:text-[#C0392B] transition-colors capitalize">{product.category}</button>
          <span>/</span>
          <span className="text-[#3D2B1F] font-medium line-clamp-1">{product.name}</span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 lg:gap-16">
          {/* Image Gallery */}
          <div className="space-y-4">
            {/* Thumbnails */}
            <div className="flex gap-3">
              <div className="flex flex-col gap-2">
                {allImages.map((img, i) => (
                  <button key={i} onClick={() => setCurrentImage(i)}
                    className={`w-16 h-16 rounded-xl overflow-hidden border-2 transition-all ${i === currentImage ? 'border-[#C0392B] shadow-md' : 'border-[#E8D5B0] hover:border-[#C0392B]/50'}`}>
                    <img src={img} alt={`View ${i + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>

              {/* Main image */}
              <div className="flex-1 relative">
                <div
                  className="relative aspect-[4/5] bg-[#F9F3EA] rounded-2xl overflow-hidden cursor-zoom-in"
                  onMouseMove={handleMouseMove}
                  onMouseEnter={() => setIsZoomed(true)}
                  onMouseLeave={() => setIsZoomed(false)}
                >
                  <img
                    src={allImages[currentImage]}
                    alt={product.name}
                    className={`w-full h-full object-cover transition-transform duration-300 ${isZoomed ? 'scale-150' : 'scale-100'}`}
                    style={isZoomed ? { transformOrigin: `${zoomPos.x}% ${zoomPos.y}%` } : {}}
                  />

                  {/* Badges */}
                  <div className="absolute top-4 left-4 flex flex-col gap-2">
                    {product.badge && <span className="px-3 py-1 bg-[#C0392B] text-white text-xs font-bold tracking-wider rounded-full">{product.badge}</span>}
                    {discount > 0 && <span className="px-3 py-1 bg-[#27AE60] text-white text-xs font-bold rounded-full">-{discount}% OFF</span>}
                  </div>

                  {/* Zoom hint */}
                  <div className={`absolute bottom-4 right-4 bg-black/40 backdrop-blur-sm text-white rounded-full p-2 transition-opacity ${isZoomed ? 'opacity-0' : 'opacity-100'}`}>
                    <ZoomIn size={16} />
                  </div>

                  {/* Navigation arrows */}
                  <button onClick={() => setCurrentImage(i => (i - 1 + allImages.length) % allImages.length)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 bg-white/80 backdrop-blur-sm rounded-full flex items-center justify-center shadow-md text-[#3D2B1F] hover:bg-white transition-colors">
                    <ChevronLeft size={18} />
                  </button>
                  <button onClick={() => setCurrentImage(i => (i + 1) % allImages.length)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 bg-white/80 backdrop-blur-sm rounded-full flex items-center justify-center shadow-md text-[#3D2B1F] hover:bg-white transition-colors">
                    <ChevronRight size={18} />
                  </button>
                </div>

                {/* 360° and AR buttons */}
                <div className="flex gap-2 mt-3">
                  <button className="flex-1 py-2 border border-[#E8D5B0] rounded-xl text-xs font-medium text-[#6B4C3B] hover:border-[#C0392B] hover:text-[#C0392B] transition-all flex items-center justify-center gap-1">
                    ↻ 360° View
                  </button>
                  <button className="flex-1 py-2 border border-[#E8D5B0] rounded-xl text-xs font-medium text-[#6B4C3B] hover:border-[#C0392B] hover:text-[#C0392B] transition-all flex items-center justify-center gap-1">
                    📱 AR Try-On
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            {/* Top meta */}
            <div>
              <div className="flex items-center justify-between">
                <p className="text-xs text-[#C0392B] tracking-widest uppercase font-bold">{product.subcategory}</p>
                <div className="flex items-center gap-2">
                  <button onClick={() => toggleWishlist(product)} className={`p-2 rounded-full border transition-all ${wishlisted ? 'bg-[#C0392B] border-[#C0392B] text-white' : 'border-[#E8D5B0] text-[#3D2B1F] hover:border-[#C0392B]'}`}>
                    <Heart size={18} className={wishlisted ? 'fill-current' : ''} />
                  </button>
                  <button className="p-2 rounded-full border border-[#E8D5B0] text-[#3D2B1F] hover:border-[#C0392B] transition-all">
                    <Share2 size={18} />
                  </button>
                </div>
              </div>

              <h1 className="text-2xl md:text-3xl font-semibold text-[#2C1810] mt-2 leading-tight" style={{ fontFamily: 'Georgia, serif' }}>
                {product.name}
              </h1>

              {/* Rating */}
              <div className="flex items-center gap-3 mt-3">
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map(star => (
                    <Star key={star} size={16} className={star <= Math.floor(product.rating) ? 'text-[#F39C12] fill-[#F39C12]' : 'text-[#E8D5B0]'} />
                  ))}
                </div>
                <span className="font-bold text-[#2C1810]">{product.rating}</span>
                <button className="text-sm text-[#C0392B] hover:underline">({product.reviews} reviews)</button>
                <span className="text-[#E8D5B0]">|</span>
                <span className="text-xs text-[#27AE60] font-semibold">{product.inStock ? '✓ In Stock' : '✗ Out of Stock'}</span>
              </div>

              {/* SKU */}
              <p className="text-xs text-[#A07850] mt-1">SKU: {product.sku}</p>
            </div>

            {/* Price */}
            <div className="bg-[#FAF7F2] rounded-2xl p-5 border border-[#E8D5B0]">
              <div className="flex items-baseline gap-3">
                <span className="text-3xl font-bold text-[#C0392B]" style={{ fontFamily: 'Georgia, serif' }}>৳{product.price.toLocaleString()}</span>
                {product.originalPrice && (
                  <>
                    <span className="text-lg text-[#A07850] line-through">৳{product.originalPrice.toLocaleString()}</span>
                    <span className="px-2 py-0.5 bg-[#C0392B] text-white text-sm font-bold rounded-full">SAVE {discount}%</span>
                  </>
                )}
              </div>
              <p className="text-xs text-[#8B4513] mt-2">Inclusive of all taxes. Artisan fair-trade price.</p>

              {/* AI explanation */}
              <button onClick={() => setShowAiExplain(!showAiExplain)} className="mt-3 flex items-center gap-2 text-xs text-[#C0392B] font-semibold">
                <Sparkles size={12} /> Why this product is perfect for you →
              </button>
              {showAiExplain && (
                <div className="mt-3 bg-white rounded-xl p-4 border border-[#C0392B]/20 text-xs text-[#6B4C3B] leading-relaxed">
                  <strong className="text-[#C0392B]">✦ AI Stylist Says:</strong> Based on your browsing history and preferences for ethnic wear, this {product.name} perfectly complements your existing wardrobe. The {product.colors[0]} colorway is trending this season and works beautifully for festive occasions. The material is ideal for Bangladesh's climate.
                </div>
              )}
            </div>

            {/* Color Selection */}
            {product.colors.length > 0 && (
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-[#2C1810] text-sm">Color: <span className="font-normal text-[#6B4C3B]">{selectedColor}</span></h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {product.colors.map(color => (
                    <button key={color} onClick={() => setSelectedColor(color)}
                      className={`px-4 py-2 rounded-full border text-sm transition-all ${selectedColor === color ? 'bg-[#2C1810] text-white border-[#2C1810] font-semibold' : 'border-[#E8D5B0] text-[#3D2B1F] hover:border-[#2C1810]'}`}>
                      {color}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Size Selection */}
            {product.sizes.length > 1 && (
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-[#2C1810] text-sm">Size: <span className="font-normal text-[#6B4C3B]">{selectedSize}</span></h3>
                  <button className="text-xs text-[#C0392B] hover:underline flex items-center gap-1"><Info size={12} /> Size Guide</button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map(size => (
                    <button key={size} onClick={() => setSelectedSize(size)}
                      className={`min-w-[50px] px-3 py-2 rounded-xl border text-sm font-medium transition-all ${selectedSize === size ? 'bg-[#2C1810] text-white border-[#2C1810]' : 'border-[#E8D5B0] text-[#3D2B1F] hover:border-[#2C1810]'}`}>
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity + Add to Cart */}
            <div className="space-y-3">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-3 border border-[#E8D5B0] rounded-full px-4 py-2.5">
                  <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className="text-[#6B4C3B] hover:text-[#C0392B] transition-colors">
                    <Minus size={16} />
                  </button>
                  <span className="w-8 text-center font-semibold text-[#2C1810]">{quantity}</span>
                  <button onClick={() => setQuantity(q => q + 1)} className="text-[#6B4C3B] hover:text-[#C0392B] transition-colors">
                    <Plus size={16} />
                  </button>
                </div>
                <p className="text-xs text-[#A07850]">Only 8 left in stock</p>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => addToCart(product, selectedColor, selectedSize, quantity)}
                  className="flex-1 py-4 bg-[#C0392B] text-white rounded-full font-semibold flex items-center justify-center gap-2 hover:bg-[#A93226] active:scale-[0.98] transition-all shadow-lg hover:shadow-xl"
                >
                  <ShoppingBag size={18} /> Add to Bag
                </button>
                <button
                  onClick={() => { addToCart(product, selectedColor, selectedSize, quantity); }}
                  className="flex-1 py-4 bg-[#2C1810] text-white rounded-full font-semibold hover:bg-[#4A2518] active:scale-[0.98] transition-all"
                >
                  Buy Now
                </button>
              </div>

              {/* One-click checkout */}
              <button className="w-full py-3 border-2 border-[#E8D5B0] rounded-full font-medium text-[#3D2B1F] hover:border-[#2C1810] transition-all flex items-center justify-center gap-2 text-sm">
                <Sparkles size={16} className="text-[#C0392B]" /> One-Click Checkout
              </button>
            </div>

            {/* Delivery Check */}
            <div className="bg-[#FAF7F2] rounded-2xl p-4 border border-[#E8D5B0]">
              <h4 className="text-sm font-semibold text-[#2C1810] mb-3 flex items-center gap-2">
                <Truck size={16} className="text-[#C0392B]" /> Check Delivery
              </h4>
              <div className="flex gap-2">
                <input type="text" placeholder="Enter postal code" value={pincode} onChange={e => setPincode(e.target.value)}
                  className="flex-1 px-4 py-2 border border-[#E8D5B0] rounded-full text-sm focus:outline-none focus:border-[#C0392B]" />
                <button onClick={checkDelivery} className="px-4 py-2 bg-[#2C1810] text-white rounded-full text-sm font-medium hover:bg-[#C0392B] transition-colors">Check</button>
              </div>
              {deliveryInfo && <p className="text-xs text-[#27AE60] mt-2">{deliveryInfo}</p>}
            </div>

            {/* Trust features */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { icon: <Shield size={18} className="text-[#27AE60]" />, title: 'Authentic', sub: 'Verified artisan product' },
                { icon: <RotateCcw size={18} className="text-[#2980B9]" />, title: '7-Day Returns', sub: 'Easy return policy' },
                { icon: <Package size={18} className="text-[#F39C12]" />, title: 'Gift Wrap', sub: 'Available on request' },
              ].map((t, i) => (
                <div key={i} className="text-center p-3 bg-[#FAF7F2] rounded-xl border border-[#E8D5B0]">
                  <div className="flex justify-center mb-1">{t.icon}</div>
                  <p className="text-xs font-semibold text-[#2C1810]">{t.title}</p>
                  <p className="text-[10px] text-[#8B4513]">{t.sub}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Product Tabs */}
        <div className="mt-16 border-t border-[#E8D5B0] pt-8">
          <div className="flex gap-0 border-b border-[#E8D5B0] mb-8">
            {(['description', 'material', 'care', 'reviews'] as const).map(tab => (
              <button key={tab} onClick={() => setActiveTab(tab)}
                className={`px-6 py-3 text-sm font-semibold capitalize border-b-2 transition-all ${activeTab === tab ? 'border-[#C0392B] text-[#C0392B]' : 'border-transparent text-[#6B4C3B] hover:text-[#3D2B1F]'}`}>
                {tab === 'reviews' ? `Reviews (${product.reviews})` : tab}
              </button>
            ))}
          </div>

          {activeTab === 'description' && (
            <div className="max-w-2xl">
              <p className="text-[#6B4C3B] leading-relaxed text-base">{product.description}</p>
              <div className="mt-6 grid grid-cols-2 gap-4">
                {[
                  { label: 'Category', value: product.category },
                  { label: 'Subcategory', value: product.subcategory },
                  { label: 'SKU', value: product.sku },
                  { label: 'Availability', value: product.inStock ? 'In Stock' : 'Out of Stock' },
                ].map(item => (
                  <div key={item.label} className="flex gap-2 text-sm">
                    <span className="text-[#A07850] min-w-[100px]">{item.label}:</span>
                    <span className="text-[#2C1810] font-medium capitalize">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'material' && (
            <div className="max-w-2xl">
              <div className="flex items-start gap-4 p-5 bg-[#FAF7F2] rounded-2xl border border-[#E8D5B0]">
                <Award className="text-[#C0392B] flex-shrink-0 mt-0.5" size={24} />
                <div>
                  <h3 className="font-semibold text-[#2C1810] mb-2">Material & Composition</h3>
                  <p className="text-[#6B4C3B] leading-relaxed">{product.material}</p>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-4">
                {['Hand-crafted', 'Ethically sourced', 'Artisan-made', 'Quality tested'].map(feat => (
                  <div key={feat} className="flex items-center gap-2 text-sm text-[#3D2B1F]">
                    <Check size={16} className="text-[#27AE60]" /> {feat}
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'care' && (
            <div className="max-w-2xl">
              <div className="flex items-start gap-4 p-5 bg-[#FAF7F2] rounded-2xl border border-[#E8D5B0]">
                <Info className="text-[#2980B9] flex-shrink-0 mt-0.5" size={24} />
                <div>
                  <h3 className="font-semibold text-[#2C1810] mb-2">Care Instructions</h3>
                  <p className="text-[#6B4C3B] leading-relaxed">{product.care}</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className="space-y-6 max-w-2xl">
              <div className="flex items-center gap-8 p-6 bg-[#FAF7F2] rounded-2xl border border-[#E8D5B0]">
                <div className="text-center">
                  <div className="text-5xl font-bold text-[#C0392B]">{product.rating}</div>
                  <div className="flex mt-2 gap-0.5">
                    {[1, 2, 3, 4, 5].map(s => <Star key={s} size={16} className={s <= Math.floor(product.rating) ? 'text-[#F39C12] fill-[#F39C12]' : 'text-[#E8D5B0]'} />)}
                  </div>
                  <p className="text-xs text-[#8B4513] mt-1">{product.reviews} reviews</p>
                </div>
                <div className="flex-1 space-y-2">
                  {[5, 4, 3, 2, 1].map(star => (
                    <div key={star} className="flex items-center gap-2">
                      <span className="text-xs text-[#8B4513] w-3">{star}</span>
                      <Star size={10} className="text-[#F39C12] fill-[#F39C12]" />
                      <div className="flex-1 h-2 bg-[#E8D5B0] rounded-full overflow-hidden">
                        <div className="h-full bg-[#F39C12] rounded-full" style={{ width: star === 5 ? '78%' : star === 4 ? '14%' : star === 3 ? '5%' : '2%' }} />
                      </div>
                      <span className="text-xs text-[#8B4513]">{star === 5 ? 78 : star === 4 ? 14 : star === 3 ? 5 : 2}%</span>
                    </div>
                  ))}
                </div>
              </div>

              {reviews.map((review, i) => (
                <div key={i} className="p-5 bg-white rounded-2xl border border-[#E8D5B0]">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-[#2C1810]">{review.name}</span>
                        {review.verified && <span className="text-[10px] text-[#27AE60] font-bold bg-[#E8F5E9] px-2 py-0.5 rounded-full">✓ Verified Purchase</span>}
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <div className="flex gap-0.5">
                          {[1, 2, 3, 4, 5].map(s => <Star key={s} size={12} className={s <= review.rating ? 'text-[#F39C12] fill-[#F39C12]' : 'text-[#E8D5B0]'} />)}
                        </div>
                        <span className="text-xs text-[#A07850]">{review.date}</span>
                      </div>
                    </div>
                  </div>
                  <p className="mt-3 text-sm text-[#6B4C3B] leading-relaxed">{review.comment}</p>
                  <div className="mt-3 flex items-center gap-4 text-xs text-[#A07850]">
                    <button className="hover:text-[#C0392B] transition-colors">👍 Helpful ({review.helpful})</button>
                    <button className="hover:text-[#C0392B] transition-colors">Share</button>
                  </div>
                </div>
              ))}

              <button className="w-full py-3 border border-[#E8D5B0] rounded-xl text-sm text-[#6B4C3B] hover:border-[#C0392B] hover:text-[#C0392B] transition-all">
                Load More Reviews
              </button>
            </div>
          )}
        </div>

        {/* Related Products */}
        {related.length > 0 && (
          <div className="mt-16">
            <div className="flex items-end justify-between mb-8">
              <div>
                <p className="text-xs text-[#C0392B] tracking-widest uppercase font-bold mb-1">You May Also Love</p>
                <h2 className="text-3xl font-light text-[#2C1810]" style={{ fontFamily: 'Georgia, serif' }}>Similar Products</h2>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
              {related.map(p => (
                <div key={p.id} onClick={() => { setSelectedProduct(p); window.scrollTo(0, 0); }}>
                  <ProductCard product={p} />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetailPage;
