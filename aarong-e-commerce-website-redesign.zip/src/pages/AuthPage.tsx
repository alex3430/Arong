import React, { useState } from 'react';
import { Eye, EyeOff, ArrowLeft, Sparkles, Check } from 'lucide-react';
import { useApp } from '../context/AppContext';

const AuthPage: React.FC = () => {
  const { setIsLoggedIn, setCurrentPage, showNotification } = useApp();
  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>('login');
  const [showPassword, setShowPassword] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', password: '', confirmPassword: '', phone: '' });
  const [agreed, setAgreed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'login') {
      setIsLoggedIn(true);
      showNotification('Welcome back to Aarong! ✨');
      setCurrentPage('home');
    } else if (mode === 'register') {
      setIsLoggedIn(true);
      showNotification('Welcome to the Aarong family! 🎉 You earned 100 welcome points!');
      setCurrentPage('home');
    } else {
      showNotification('Password reset email sent!', 'info');
      setMode('login');
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF7F2] flex">
      {/* Left Visual */}
      <div className="hidden md:flex w-1/2 bg-gradient-to-br from-[#2C1810] to-[#8B4513] items-center justify-center relative overflow-hidden">
        <img src="/images/hero-1.jpg" alt="Aarong" className="absolute inset-0 w-full h-full object-cover opacity-30" />
        <div className="relative text-center text-white p-12">
          <div className="w-16 h-16 bg-[#C0392B] rounded-full flex items-center justify-center mx-auto mb-6">
            <span className="text-white font-bold text-2xl">আ</span>
          </div>
          <h2 className="text-4xl font-light mb-4" style={{ fontFamily: 'Georgia, serif' }}>
            Your Heritage,<br /><em className="font-bold italic">Your Story</em>
          </h2>
          <p className="text-white/70 leading-relaxed">
            Join the Aarong community and unlock exclusive access to handcrafted Bengali artistry, loyalty rewards, and personalized shopping experiences.
          </p>
          <div className="mt-8 space-y-3 text-sm text-left">
            {[
              '✦ Earn loyalty points on every purchase',
              '✦ Access exclusive member-only offers',
              '✦ Free shipping on orders over ৳3,000',
              '✦ Early access to new collections',
            ].map(b => <p key={b} className="text-white/80">{b}</p>)}
          </div>
        </div>
      </div>

      {/* Right Form */}
      <div className="flex-1 flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-md">
          <button onClick={() => setCurrentPage('home')} className="flex items-center gap-2 text-[#8B4513] hover:text-[#C0392B] transition-colors mb-8 text-sm">
            <ArrowLeft size={16} /> Back to Home
          </button>

          <div className="mb-8">
            <div className="flex gap-4 border-b border-[#E8D5B0]">
              {['login', 'register'].map(m => (
                <button key={m} onClick={() => setMode(m as 'login' | 'register')}
                  className={`pb-3 text-sm font-semibold capitalize border-b-2 transition-all ${mode === m ? 'border-[#C0392B] text-[#C0392B]' : 'border-transparent text-[#A07850] hover:text-[#3D2B1F]'}`}>
                  {m === 'login' ? 'Sign In' : 'Create Account'}
                </button>
              ))}
            </div>
          </div>

          {mode === 'forgot' ? (
            <div>
              <h1 className="text-2xl font-bold text-[#2C1810] mb-2" style={{ fontFamily: 'Georgia, serif' }}>Reset Password</h1>
              <p className="text-[#6B4C3B] text-sm mb-6">Enter your email and we'll send you a reset link</p>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">Email Address</label>
                  <input type="email" required placeholder="your@email.com" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })}
                    className="w-full px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B]" />
                </div>
                <button type="submit" className="w-full py-4 bg-[#C0392B] text-white rounded-full font-semibold hover:bg-[#A93226] transition-colors">
                  Send Reset Link
                </button>
                <button type="button" onClick={() => setMode('login')} className="w-full text-sm text-[#6B4C3B] hover:text-[#C0392B] transition-colors">
                  ← Back to Sign In
                </button>
              </form>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <h1 className="text-2xl font-bold text-[#2C1810] mb-1" style={{ fontFamily: 'Georgia, serif' }}>
                {mode === 'login' ? 'Welcome Back' : 'Join Aarong'}
              </h1>
              <p className="text-[#6B4C3B] text-sm mb-4">
                {mode === 'login' ? 'Sign in to your Aarong account' : 'Create your account and earn 100 welcome points'}
              </p>

              {mode === 'register' && (
                <div>
                  <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">Full Name</label>
                  <input type="text" required placeholder="Nadia Islam" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}
                    className="w-full px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B]" />
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">Email Address</label>
                <input type="email" required placeholder="your@email.com" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })}
                  className="w-full px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B]" />
              </div>

              {mode === 'register' && (
                <div>
                  <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">Phone Number</label>
                  <input type="tel" placeholder="+880 1X..." value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })}
                    className="w-full px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B]" />
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">Password</label>
                <div className="relative">
                  <input type={showPassword ? 'text' : 'password'} required placeholder="••••••••" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })}
                    className="w-full px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B] pr-12" />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-[#A07850] hover:text-[#C0392B] transition-colors">
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              {mode === 'register' && (
                <>
                  <div>
                    <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">Confirm Password</label>
                    <input type="password" required placeholder="••••••••" value={form.confirmPassword} onChange={e => setForm({ ...form, confirmPassword: e.target.value })}
                      className="w-full px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B]" />
                  </div>
                  <label className="flex items-start gap-3 cursor-pointer">
                    <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 mt-0.5 transition-all ${agreed ? 'bg-[#C0392B] border-[#C0392B]' : 'border-[#C8A87E]'}`}
                      onClick={() => setAgreed(!agreed)}>
                      {agreed && <Check size={12} className="text-white" />}
                    </div>
                    <span className="text-xs text-[#6B4C3B] leading-relaxed">
                      I agree to Aarong's <button type="button" className="text-[#C0392B] hover:underline">Terms of Service</button> and <button type="button" className="text-[#C0392B] hover:underline">Privacy Policy</button>. I consent to receiving marketing emails.
                    </span>
                  </label>
                </>
              )}

              {mode === 'login' && (
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 text-sm text-[#6B4C3B] cursor-pointer">
                    <input type="checkbox" className="accent-[#C0392B]" /> Remember me
                  </label>
                  <button type="button" onClick={() => setMode('forgot')} className="text-sm text-[#C0392B] hover:underline">
                    Forgot password?
                  </button>
                </div>
              )}

              <button type="submit" className="w-full py-4 bg-[#C0392B] text-white rounded-full font-semibold hover:bg-[#A93226] active:scale-[0.98] transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2">
                <Sparkles size={18} />
                {mode === 'login' ? 'Sign In' : 'Create Account & Earn 100 Points'}
              </button>

              <div className="relative my-4">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-[#E8D5B0]" />
                </div>
                <div className="relative flex justify-center">
                  <span className="bg-[#FAF7F2] px-3 text-xs text-[#A07850]">or continue with</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button type="button" className="flex items-center justify-center gap-2 px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm font-medium text-[#3D2B1F] hover:border-[#C0392B] transition-colors">
                  <span className="text-lg">G</span> Google
                </button>
                <button type="button" className="flex items-center justify-center gap-2 px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm font-medium text-[#3D2B1F] hover:border-[#C0392B] transition-colors">
                  <span className="text-lg">f</span> Facebook
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default AuthPage;
