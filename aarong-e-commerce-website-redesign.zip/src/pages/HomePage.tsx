import React, { useState, useEffect, useRef } from 'react';
import {
  ChevronLeft, ChevronRight, Star, Heart, ShoppingBag, ArrowRight,
  Sparkles, Mic, Eye, Zap, Award, Leaf, Users,
  Mail, ChevronDown
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { products } from '../data/products';

// Hero Slider
const heroSlides = [
  {
    image: '/images/hero-1.jpg',
    tag: '✦ Heritage Collection 2024',
    title: 'The Art of',
    titleBold: 'Bengali Craft',
    subtitle: 'Handwoven stories in silk and thread — where ancient artistry meets modern grace.',
    cta: 'Explore Women\'s',
    ctaSecondary: 'View Lookbook',
    category: 'women',
    badge: 'Eid Special',
    bg: 'from-[#2C1810]/70 to-[#2C1810]/20',
  },
  {
    image: '/images/hero-2.jpg',
    tag: '✦ TAAGA Man Collection',
    title: 'Refined',
    titleBold: 'Heritage Style',
    subtitle: 'Premium panjabis and shirts crafted with generations of Bangladeshi textile mastery.',
    cta: 'Shop Men\'s',
    ctaSecondary: 'New Arrivals',
    category: 'men',
    badge: 'New Season',
    bg: 'from-[#1A2C2C]/70 to-[#1A2C2C]/20',
  },
  {
    image: '/images/hero-3.jpg',
    tag: '✦ Bridal Collection 2024',
    title: 'Your Perfect',
    titleBold: 'Wedding Story',
    subtitle: 'Exquisite bridal wear and jewelry crafted for the most sacred moments of your life.',
    cta: 'Explore Wedding',
    ctaSecondary: 'Book Consultation',
    category: 'wedding',
    badge: 'Bridal Season',
    bg: 'from-[#2C1820]/70 to-[#2C1820]/20',
  },
];

const HeroSlider: React.FC = () => {
  const [current, setCurrent] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const { setCurrentPage, setSelectedCategory } = useApp();
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const goTo = (idx: number) => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrent(idx);
    setTimeout(() => setIsAnimating(false), 600);
  };

  useEffect(() => {
    intervalRef.current = setInterval(() => {
      setCurrent(c => (c + 1) % heroSlides.length);
    }, 6000);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, []);

  const slide = heroSlides[current];

  return (
    <section className="relative h-[90vh] min-h-[600px] max-h-[900px] overflow-hidden">
      {/* Background */}
      {heroSlides.map((s, i) => (
        <div key={i} className={`absolute inset-0 transition-opacity duration-1000 ${i === current ? 'opacity-100' : 'opacity-0'}`}>
          <img src={s.image} alt={s.title} className="w-full h-full object-cover object-top" />
          <div className={`absolute inset-0 bg-gradient-to-r ${s.bg}`} />
        </div>
      ))}

      {/* Decorative pattern overlay */}
      <div className="absolute inset-0 opacity-5" style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
      }} />

      {/* Content */}
      <div className="relative h-full flex items-center">
        <div className="max-w-7xl mx-auto px-8 w-full">
          <div className="max-w-2xl">
            <span className={`inline-block text-[#F5E6C8] text-sm tracking-[0.2em] uppercase mb-4 transition-all duration-700 ${isAnimating ? 'opacity-0 -translate-y-4' : 'opacity-100 translate-y-0'}`}>
              {slide.tag}
            </span>
            <h1 className={`text-5xl md:text-7xl font-light text-white mb-3 leading-[1.05] transition-all duration-700 delay-100 ${isAnimating ? 'opacity-0 -translate-y-4' : 'opacity-100 translate-y-0'}`} style={{ fontFamily: 'Georgia, serif' }}>
              {slide.title}
              <br />
              <span className="font-bold italic text-[#F5E6C8]">{slide.titleBold}</span>
            </h1>
            <p className={`text-white/80 text-lg mb-8 leading-relaxed max-w-lg transition-all duration-700 delay-200 ${isAnimating ? 'opacity-0 -translate-y-4' : 'opacity-100 translate-y-0'}`}>
              {slide.subtitle}
            </p>
            <div className={`flex items-center gap-4 transition-all duration-700 delay-300 ${isAnimating ? 'opacity-0 -translate-y-4' : 'opacity-100 translate-y-0'}`}>
              <button
                onClick={() => { setSelectedCategory(slide.category); setCurrentPage('category'); }}
                className="px-8 py-4 bg-[#C0392B] text-white rounded-full font-semibold flex items-center gap-2 hover:bg-[#A93226] active:scale-[0.98] transition-all shadow-lg hover:shadow-xl"
              >
                {slide.cta} <ArrowRight size={18} />
              </button>
              <button className="px-8 py-4 border-2 border-white/60 text-white rounded-full font-semibold hover:bg-white/10 transition-all backdrop-blur-sm">
                {slide.ctaSecondary}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation arrows */}
      <button onClick={() => goTo((current - 1 + heroSlides.length) % heroSlides.length)}
        className="absolute left-6 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/20 hover:bg-white/40 backdrop-blur-sm rounded-full flex items-center justify-center text-white transition-all border border-white/30">
        <ChevronLeft size={22} />
      </button>
      <button onClick={() => goTo((current + 1) % heroSlides.length)}
        className="absolute right-6 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/20 hover:bg-white/40 backdrop-blur-sm rounded-full flex items-center justify-center text-white transition-all border border-white/30">
        <ChevronRight size={22} />
      </button>

      {/* Indicators */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-3">
        {heroSlides.map((_, i) => (
          <button key={i} onClick={() => goTo(i)}
            className={`transition-all duration-300 rounded-full ${i === current ? 'w-8 h-2 bg-[#F5E6C8]' : 'w-2 h-2 bg-white/40 hover:bg-white/70'}`} />
        ))}
      </div>

      {/* Scroll hint */}
      <div className="absolute bottom-8 right-8 text-white/60 flex flex-col items-center gap-2 text-xs">
        <span className="tracking-widest uppercase" style={{ writingMode: 'vertical-rl' }}>Scroll</span>
        <ChevronDown size={16} className="animate-bounce" />
      </div>
    </section>
  );
};

// Quick Category Strip
const CategoryStrip: React.FC = () => {
  const { setCurrentPage, setSelectedCategory } = useApp();
  const cats = [
    { id: 'women', label: 'Women', icon: '👗', color: '#FAD7A0' },
    { id: 'men', label: 'Men', icon: '👔', color: '#AED6F1' },
    { id: 'kids', label: 'Kids', icon: '🧒', color: '#A9DFBF' },
    { id: 'home-decor', label: 'Home', icon: '🏺', color: '#F9E79F' },
    { id: 'jewellery', label: 'Jewellery', icon: '💍', color: '#F1948A' },
    { id: 'wedding', label: 'Wedding', icon: '💐', color: '#D7BDE2' },
    { id: 'gifts', label: 'Gifts', icon: '🎁', color: '#A3E4D7' },
    { id: 'beauty', label: 'Beauty', icon: '✨', color: '#FDEBD0' },
  ];
  return (
    <section className="py-8 bg-[#FAF7F2] border-b border-[#E8D5B0]">
      <div className="max-w-7xl mx-auto px-8">
        <div className="grid grid-cols-4 md:grid-cols-8 gap-4">
          {cats.map(cat => (
            <button key={cat.id} onClick={() => { setSelectedCategory(cat.id); setCurrentPage('category'); }}
              className="flex flex-col items-center gap-2 group">
              <div className="w-14 h-14 rounded-full flex items-center justify-center text-2xl group-hover:scale-110 transition-transform shadow-sm"
                style={{ backgroundColor: cat.color }}>
                {cat.icon}
              </div>
              <span className="text-xs font-medium text-[#3D2B1F] group-hover:text-[#C0392B] transition-colors">{cat.label}</span>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};

// Product Card
const ProductCard: React.FC<{ product: typeof products[0] }> = ({ product }) => {
  const { addToCart, toggleWishlist, isWishlisted, setSelectedProduct, setCurrentPage } = useApp();
  const [isHovered, setIsHovered] = useState(false);
  const wishlisted = isWishlisted(product.id);
  const discount = product.originalPrice ? Math.round((1 - product.price / product.originalPrice) * 100) : 0;

  return (
    <div
      className="group bg-white rounded-2xl overflow-hidden border border-[#E8D5B0] hover:border-[#C0392B]/30 hover:shadow-xl transition-all duration-300"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Image */}
      <div className="relative aspect-[3/4] overflow-hidden bg-[#F9F3EA] cursor-pointer"
        onClick={() => { setSelectedProduct(product); setCurrentPage('product'); }}>
        <img
          src={isHovered && product.images[1] ? product.images[1] : product.images[0]}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5">
          {product.badge && (
            <span className="px-2 py-1 bg-[#C0392B] text-white text-[10px] font-bold tracking-wider rounded-full">
              {product.badge}
            </span>
          )}
          {product.isNew && (
            <span className="px-2 py-1 bg-[#2C1810] text-[#F5E6C8] text-[10px] font-bold tracking-wider rounded-full">
              NEW
            </span>
          )}
          {discount > 0 && (
            <span className="px-2 py-1 bg-[#27AE60] text-white text-[10px] font-bold rounded-full">
              -{discount}%
            </span>
          )}
        </div>

        {/* Action buttons */}
        <div className={`absolute right-3 top-3 flex flex-col gap-2 transition-all duration-300 ${isHovered ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-4'}`}>
          <button
            onClick={(e) => { e.stopPropagation(); toggleWishlist(product); }}
            className={`w-9 h-9 rounded-full flex items-center justify-center shadow-md transition-all ${wishlisted ? 'bg-[#C0392B] text-white' : 'bg-white text-[#3D2B1F] hover:bg-[#C0392B] hover:text-white'}`}
          >
            <Heart size={15} className={wishlisted ? 'fill-current' : ''} />
          </button>
          <button className="w-9 h-9 bg-white rounded-full flex items-center justify-center shadow-md text-[#3D2B1F] hover:bg-[#2C1810] hover:text-white transition-all">
            <Eye size={15} />
          </button>
        </div>

        {/* Add to bag hover */}
        <div className={`absolute bottom-0 left-0 right-0 transition-all duration-300 ${isHovered ? 'translate-y-0 opacity-100' : 'translate-y-full opacity-0'}`}>
          <button
            onClick={(e) => { e.stopPropagation(); addToCart(product, product.colors[0], product.sizes[0]); }}
            className="w-full py-3 bg-[#2C1810]/90 backdrop-blur-sm text-white text-sm font-semibold flex items-center justify-center gap-2 hover:bg-[#C0392B] transition-colors"
          >
            <ShoppingBag size={15} /> Add to Bag
          </button>
        </div>
      </div>

      {/* Info */}
      <div className="p-4 cursor-pointer" onClick={() => { setSelectedProduct(product); setCurrentPage('product'); }}>
        <p className="text-[10px] text-[#A07850] uppercase tracking-widest mb-1">{product.subcategory}</p>
        <h3 className="text-sm font-semibold text-[#2C1810] line-clamp-2 mb-2 leading-snug hover:text-[#C0392B] transition-colors">{product.name}</h3>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-base font-bold text-[#C0392B]">৳{product.price.toLocaleString()}</span>
            {product.originalPrice && (
              <span className="text-xs text-[#A07850] line-through">৳{product.originalPrice.toLocaleString()}</span>
            )}
          </div>
          <div className="flex items-center gap-1">
            <Star size={12} className="text-[#F39C12] fill-[#F39C12]" />
            <span className="text-xs text-[#6B4C3B]">{product.rating} ({product.reviews})</span>
          </div>
        </div>
        {/* Color dots */}
        {product.colors.length > 1 && (
          <div className="flex items-center gap-1 mt-2">
            {product.colors.slice(0, 4).map(c => (
              <div key={c} className="w-3 h-3 rounded-full border border-[#E8D5B0]" title={c}
                style={{ backgroundColor: c === 'Ivory' ? '#FFFFF0' : c === 'Deep Red' ? '#8B0000' : c === 'Teal' ? '#008080' : c === 'Indigo Blue' ? '#4B0082' : c === 'Mustard' ? '#FFDB58' : c === 'Forest Green' ? '#228B22' : c === 'Rust Orange' ? '#B7410E' : c === 'White' ? '#FFF' : c === 'Navy' ? '#000080' : c === 'Pink' ? '#FFC0CB' : '#C8A87E' }} />
            ))}
            {product.colors.length > 4 && <span className="text-[10px] text-[#A07850]">+{product.colors.length - 4}</span>}
          </div>
        )}
      </div>
    </div>
  );
};

// Section wrapper
const SectionHeader: React.FC<{ tag?: string; title: string; subtitle?: string; cta?: string; onCta?: () => void }> = ({ tag, title, subtitle, cta, onCta }) => (
  <div className="flex items-end justify-between mb-8 md:mb-12">
    <div>
      {tag && <p className="text-xs text-[#C0392B] tracking-[0.3em] uppercase font-bold mb-2">{tag}</p>}
      <h2 className="text-3xl md:text-4xl font-light text-[#2C1810] leading-tight" style={{ fontFamily: 'Georgia, serif' }}>
        {title}
      </h2>
      {subtitle && <p className="text-[#6B4C3B] mt-2 max-w-lg">{subtitle}</p>}
    </div>
    {cta && (
      <button onClick={onCta} className="hidden md:flex items-center gap-2 text-sm font-semibold text-[#C0392B] hover:gap-3 transition-all border-b border-[#C0392B] pb-0.5">
        {cta} <ArrowRight size={16} />
      </button>
    )}
  </div>
);

// New Arrivals section
const NewArrivalsSection: React.FC = () => {
  const { setCurrentPage } = useApp();
  const newProducts = products.filter(p => p.isNew).slice(0, 4);
  return (
    <section className="py-16 px-4 md:px-8 max-w-7xl mx-auto">
      <SectionHeader
        tag="Just Landed"
        title="New Arrivals"
        subtitle="Fresh from our artisans — the latest additions to our handcrafted collection"
        cta="View All New"
        onCta={() => setCurrentPage('category')}
      />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
        {newProducts.map(p => <ProductCard key={p.id} product={p} />)}
      </div>
    </section>
  );
};

// Trending Section
const TrendingSection: React.FC = () => {
  const { setCurrentPage, setSelectedCategory } = useApp();
  const trending = products.filter(p => p.isTrending).slice(0, 4);
  return (
    <section className="py-16 px-4 md:px-8 bg-[#FAF7F2]">
      <div className="max-w-7xl mx-auto">
        <SectionHeader
          tag="Most Loved"
          title="Trending Now"
          subtitle="Our community's most-wanted pieces — celebrated by thousands of happy customers"
          cta="See All Trends"
          onCta={() => { setSelectedCategory('women'); setCurrentPage('category'); }}
        />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {trending.map(p => <ProductCard key={p.id} product={p} />)}
        </div>
      </div>
    </section>
  );
};

// Featured Categories Grid
const FeaturedCategories: React.FC = () => {
  const { setSelectedCategory, setCurrentPage } = useApp();
  const cats = [
    { id: 'women', title: 'Women\'s Collection', sub: 'Sarees, Kurtis & More', image: '/images/cat-women.jpg', span: 'md:col-span-2 md:row-span-2' },
    { id: 'jewellery', title: 'Fine Jewellery', sub: 'Handcrafted Pieces', image: '/images/cat-jewellery.jpg', span: '' },
    { id: 'home-decor', title: 'Home Décor', sub: 'Artisan Crafts', image: '/images/cat-home.jpg', span: '' },
  ];
  return (
    <section className="py-16 px-4 md:px-8 max-w-7xl mx-auto">
      <SectionHeader tag="Curated For You" title="Featured Collections" />
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6 auto-rows-[240px]">
        {cats.map(cat => (
          <button
            key={cat.id}
            onClick={() => { setSelectedCategory(cat.id); setCurrentPage('category'); }}
            className={`relative overflow-hidden rounded-2xl group ${cat.span}`}
          >
            <img src={cat.image} alt={cat.title} className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#2C1810]/80 via-[#2C1810]/20 to-transparent" />
            <div className="absolute bottom-0 left-0 p-5 text-left">
              <p className="text-white text-xs tracking-widest uppercase mb-1 opacity-80">{cat.sub}</p>
              <h3 className="text-white font-bold text-lg" style={{ fontFamily: 'Georgia, serif' }}>{cat.title}</h3>
              <span className="inline-flex items-center gap-1 text-[#F5E6C8] text-sm mt-2 group-hover:gap-2 transition-all">
                Shop Now <ArrowRight size={14} />
              </span>
            </div>
          </button>
        ))}
      </div>
    </section>
  );
};

// Promotional Campaign Block
const PromoBlock: React.FC = () => {
  const { setSelectedCategory, setCurrentPage } = useApp();
  return (
    <section className="py-8 px-4 md:px-8 max-w-7xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { bg: 'bg-gradient-to-br from-[#8B0000] to-[#C0392B]', emoji: '🌙', title: 'Eid Collection', sub: 'Up to 30% off on selected items', cta: 'Shop Eid', cat: 'women' },
          { bg: 'bg-gradient-to-br from-[#2C1810] to-[#6B4C3B]', emoji: '💍', title: 'Wedding Season', sub: 'Exclusive bridal & groom collections', cta: 'View Wedding', cat: 'wedding' },
          { bg: 'bg-gradient-to-br from-[#1A4A3A] to-[#27AE60]', emoji: '🌿', title: 'Aarong Earth', sub: 'Natural & organic beauty collection', cta: 'Explore Beauty', cat: 'beauty' },
        ].map((block, i) => (
          <div key={i} className={`${block.bg} rounded-2xl p-8 text-white flex flex-col gap-3 relative overflow-hidden`}>
            <div className="text-4xl mb-2">{block.emoji}</div>
            <h3 className="text-xl font-bold" style={{ fontFamily: 'Georgia, serif' }}>{block.title}</h3>
            <p className="text-white/80 text-sm">{block.sub}</p>
            <button
              onClick={() => { setSelectedCategory(block.cat); setCurrentPage('category'); }}
              className="mt-2 self-start px-5 py-2 bg-white/20 hover:bg-white/30 rounded-full text-sm font-semibold backdrop-blur-sm transition-all flex items-center gap-2"
            >
              {block.cta} <ArrowRight size={14} />
            </button>
            <div className="absolute -right-4 -bottom-4 w-24 h-24 bg-white/5 rounded-full" />
            <div className="absolute -right-8 -top-8 w-32 h-32 bg-white/5 rounded-full" />
          </div>
        ))}
      </div>
    </section>
  );
};

// AI Features Strip
const AIFeaturesStrip: React.FC = () => {
  const { setCurrentPage } = useApp();
  return (
    <section className="py-12 px-4 md:px-8 bg-gradient-to-r from-[#2C1810] to-[#4A2518] text-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-10">
          <span className="inline-flex items-center gap-2 text-[#F5E6C8] text-xs tracking-widest uppercase font-bold mb-3">
            <Sparkles size={14} /> Powered by AI
          </span>
          <h2 className="text-3xl font-light" style={{ fontFamily: 'Georgia, serif' }}>
            Your Personal Style Intelligence
          </h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { icon: <Sparkles size={28} />, title: 'AI Stylist', desc: 'Get personalized outfit recommendations based on your preferences', action: () => setCurrentPage('ai-stylist') },
            { icon: <Mic size={28} />, title: 'Voice Shopping', desc: 'Search with your voice — just say what you\'re looking for', action: () => {} },
            { icon: <Eye size={28} />, title: 'Visual Search', desc: 'Upload any image and find similar products instantly', action: () => {} },
            { icon: <Zap size={28} />, title: 'Smart Bundles', desc: 'AI-curated outfit bundles for complete looks at better prices', action: () => {} },
          ].map((feature, i) => (
            <button key={i} onClick={feature.action} className="text-center p-6 bg-white/10 hover:bg-white/20 rounded-2xl transition-all group">
              <div className="w-14 h-14 bg-[#C0392B] rounded-full flex items-center justify-center mx-auto mb-4 text-white group-hover:scale-110 transition-transform">
                {feature.icon}
              </div>
              <h3 className="font-semibold text-[#F5E6C8] mb-2">{feature.title}</h3>
              <p className="text-white/60 text-xs leading-relaxed">{feature.desc}</p>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};

// Brand Story Section
const BrandStorySection: React.FC = () => {
  const { setCurrentPage } = useApp();
  return (
    <section className="py-20 px-4 md:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <img src="/images/brand-story.jpg" alt="Aarong Artisans" className="w-full h-[500px] object-cover rounded-2xl shadow-2xl" />
            <div className="absolute -bottom-6 -right-6 bg-[#C0392B] text-white p-6 rounded-2xl shadow-xl">
              <div className="text-4xl font-bold" style={{ fontFamily: 'Georgia, serif' }}>1978</div>
              <div className="text-sm text-white/80">Est. in Bangladesh</div>
            </div>
            <div className="absolute top-6 left-6 bg-white/90 backdrop-blur-sm text-[#2C1810] p-4 rounded-xl shadow-lg">
              <div className="text-2xl font-bold text-[#C0392B]">65,000+</div>
              <div className="text-xs text-[#6B4C3B]">Artisans Empowered</div>
            </div>
          </div>
          <div>
            <span className="text-xs font-bold tracking-[0.3em] text-[#C0392B] uppercase">Our Heritage</span>
            <h2 className="text-4xl md:text-5xl font-light text-[#2C1810] mt-3 mb-6 leading-tight" style={{ fontFamily: 'Georgia, serif' }}>
              More Than a Brand —<br /><em className="font-bold italic">A Movement</em>
            </h2>
            <div className="space-y-4 text-[#6B4C3B] leading-relaxed">
              <p>
                Founded in <strong>1978 by BRAC</strong>, Aarong (Bengali: আড়ং, meaning "Village Fair") was born from a vision to transform rural artisanship into a global celebration of Bangladeshi heritage.
              </p>
              <p>
                What began as a small shop in Manikganj has grown into Bangladesh's most iconic lifestyle brand — with <strong>30 flagship stores</strong> across the country, including the world's largest craft store in Dhanmondi, Dhaka.
              </p>
              <p>
                Every product carries the fingerprints of our <strong>65,000+ artisans</strong> — weavers of Jamdani, embroiderers of Nakshi Kantha, potters of Rajshahi — preserving 400-year-old traditions while creating sustainable livelihoods.
              </p>
            </div>
            <div className="grid grid-cols-3 gap-4 mt-8">
              {[
                { value: '46+', label: 'Years of Heritage' },
                { value: '30', label: 'Stores Nationwide' },
                { value: '65K+', label: 'Artisans Empowered' },
              ].map((stat, i) => (
                <div key={i} className="text-center p-4 bg-[#FAF7F2] rounded-xl border border-[#E8D5B0]">
                  <div className="text-2xl font-bold text-[#C0392B]" style={{ fontFamily: 'Georgia, serif' }}>{stat.value}</div>
                  <div className="text-xs text-[#8B4513] mt-1">{stat.label}</div>
                </div>
              ))}
            </div>
            <button onClick={() => setCurrentPage('about')} className="mt-8 flex items-center gap-2 text-[#C0392B] font-semibold hover:gap-3 transition-all border-b border-[#C0392B] pb-0.5">
              Read Our Full Story <ArrowRight size={16} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

// Trust Badges
const TrustBadges: React.FC = () => (
  <section className="py-12 px-4 md:px-8 bg-[#FAF7F2] border-y border-[#E8D5B0]">
    <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6">
      {[
        { icon: <Leaf size={28} className="text-[#27AE60]" />, title: '100% Authentic', desc: 'All products handcrafted by verified artisans' },
        { icon: <Truck size={28} className="text-[#C0392B]" />, title: 'Nationwide Delivery', desc: 'Delivering to all districts of Bangladesh' },
        { icon: <Award size={28} className="text-[#F39C12]" />, title: 'Heritage Certified', desc: 'UNESCO recognized traditional crafts' },
        { icon: <Users size={28} className="text-[#2980B9]" />, title: '500K+ Happy Customers', desc: 'Trusted by families for 46+ years' },
      ].map((badge, i) => (
        <div key={i} className="flex flex-col items-center text-center gap-3 p-4">
          <div className="w-14 h-14 bg-white rounded-full flex items-center justify-center shadow-md">
            {badge.icon}
          </div>
          <div>
            <h4 className="font-semibold text-[#2C1810] text-sm">{badge.title}</h4>
            <p className="text-xs text-[#8B4513] mt-1">{badge.desc}</p>
          </div>
        </div>
      ))}
    </div>
  </section>
);

// Truck component
const Truck: React.FC<{ size: number; className?: string }> = ({ size, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className={className}>
    <rect x="1" y="3" width="15" height="13" /><polygon points="16 8 20 8 23 11 23 16 16 16 16 8" /><circle cx="5.5" cy="18.5" r="2.5" /><circle cx="18.5" cy="18.5" r="2.5" />
  </svg>
);

// Newsletter
const NewsletterSection: React.FC = () => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  return (
    <section className="py-20 px-4 md:px-8 bg-gradient-to-br from-[#2C1810] to-[#8B4513]">
      <div className="max-w-2xl mx-auto text-center">
        <span className="inline-block text-[#F5E6C8] text-xs tracking-[0.3em] uppercase mb-4">Join Our Circle</span>
        <h2 className="text-4xl font-light text-white mb-4" style={{ fontFamily: 'Georgia, serif' }}>
          Stories of Craft & Culture
        </h2>
        <p className="text-white/70 mb-8">
          Subscribe for new arrivals, exclusive offers, artisan stories, and your first purchase discount of 10%.
        </p>
        {!submitted ? (
          <form onSubmit={e => { e.preventDefault(); if (email) setSubmitted(true); }} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <div className="relative flex-1">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40" size={16} />
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="Your email address"
                className="w-full pl-11 pr-4 py-4 bg-white/10 border border-white/20 text-white placeholder-white/40 rounded-full focus:outline-none focus:border-white/60 backdrop-blur-sm"
                required
              />
            </div>
            <button type="submit" className="px-7 py-4 bg-[#C0392B] text-white font-semibold rounded-full hover:bg-[#A93226] transition-colors flex items-center justify-center gap-2 whitespace-nowrap">
              Subscribe <ArrowRight size={16} />
            </button>
          </form>
        ) : (
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
            <div className="text-3xl mb-3">✨</div>
            <h3 className="text-white font-semibold">Welcome to the Aarong Family!</h3>
            <p className="text-white/70 text-sm mt-1">Check your email for your exclusive 10% discount code.</p>
          </div>
        )}
        <p className="text-white/40 text-xs mt-4">No spam, ever. Unsubscribe anytime.</p>
      </div>
    </section>
  );
};

// Social Section
const SocialSection: React.FC = () => (
  <section className="py-12 px-4 md:px-8 max-w-7xl mx-auto">
    <div className="text-center mb-8">
      <p className="text-xs text-[#C0392B] tracking-[0.3em] uppercase font-bold mb-2">Community</p>
      <h2 className="text-3xl font-light text-[#2C1810]" style={{ fontFamily: 'Georgia, serif' }}>
        #MyAarong Moments
      </h2>
      <p className="text-[#6B4C3B] mt-2">Follow us @aarong.official for daily inspiration</p>
    </div>
    <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
      {[
        'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=200&q=70',
        'https://images.unsplash.com/photo-1614252369475-531eba835eb1?w=200&q=70',
        'https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=200&q=70',
        'https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?w=200&q=70',
        'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=200&q=70',
        'https://images.unsplash.com/photo-1602526430780-782d6b1783fa?w=200&q=70',
      ].map((img, i) => (
        <div key={i} className="relative aspect-square overflow-hidden rounded-xl group cursor-pointer">
          <img src={img} alt={`Social ${i + 1}`} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
          <div className="absolute inset-0 bg-[#C0392B]/0 group-hover:bg-[#C0392B]/30 transition-all duration-300 flex items-center justify-center">
            <span className="text-white opacity-0 group-hover:opacity-100 transition-opacity text-2xl">📷</span>
          </div>
        </div>
      ))}
    </div>
    <div className="flex justify-center gap-6 mt-8">
      {[
        { icon: '📷', label: 'Instagram', count: '485K' },
        { icon: '👥', label: 'Facebook', count: '1.2M' },
        { icon: '🐦', label: 'Twitter', count: '82K' },
        { icon: '▶️', label: 'YouTube', count: '95K' },
      ].map((s, i) => (
        <button key={i} className="flex items-center gap-2 px-4 py-2 border border-[#E8D5B0] rounded-full text-sm text-[#3D2B1F] hover:border-[#C0392B] hover:text-[#C0392B] transition-all">
          <span>{s.icon}</span> {s.label} <span className="text-xs text-[#A07850]">{s.count}</span>
        </button>
      ))}
    </div>
  </section>
);

// Featured Products - All
const FeaturedProductsSection: React.FC = () => {
  const { setCurrentPage } = useApp();
  const featured = products.filter(p => p.isFeatured).slice(0, 4);
  return (
    <section className="py-16 px-4 md:px-8 max-w-7xl mx-auto">
      <SectionHeader
        tag="Editor's Pick"
        title="Featured Products"
        subtitle="Hand-selected by our curators — the finest from our artisan community"
        cta="Browse All"
        onCta={() => setCurrentPage('category')}
      />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
        {featured.map(p => <ProductCard key={p.id} product={p} />)}
      </div>
    </section>
  );
};

const HomePage: React.FC = () => {
  return (
    <main>
      <HeroSlider />
      <CategoryStrip />
      <NewArrivalsSection />
      <PromoBlock />
      <FeaturedCategories />
      <TrendingSection />
      <AIFeaturesStrip />
      <BrandStorySection />
      <TrustBadges />
      <FeaturedProductsSection />
      <SocialSection />
      <NewsletterSection />
    </main>
  );
};

export default HomePage;
export { ProductCard };
