import React, { useState } from 'react';
import { MapPin, Phone, Clock, ChevronRight, Search, Navigation } from 'lucide-react';
import { useApp } from '../context/AppContext';

const stores = [
  { id: 1, name: 'Dhanmondi Flagship Store', address: 'House 12, Road 27, Dhanmondi, Dhaka 1209', city: 'Dhaka', phone: '+880 2-9667055', hours: 'Sat-Thu: 10AM-9PM, Fri: 3PM-9PM', isNew: true, isFlagship: true, size: '60,000 sq ft', features: ['Playpen', 'The Orange Parrot Restaurant', 'Tailoring', 'Gift Wrapping'] },
  { id: 2, name: 'Gulshan Circle 1', address: 'Plot 3, Road 90, Gulshan 2, Dhaka 1212', city: 'Dhaka', phone: '+880 2-9886555', hours: 'Sat-Thu: 10AM-9PM, Fri: 3PM-9PM', isNew: false, isFlagship: false, size: '8,000 sq ft', features: ['Gift Wrapping', 'Tailoring'] },
  { id: 3, name: 'Uttara Store', address: 'House 36, Road 7, Sector 3, Uttara, Dhaka 1230', city: 'Dhaka', phone: '+880 2-8915566', hours: 'Sat-Thu: 10AM-9PM, Fri: 3PM-9PM', isNew: false, isFlagship: false, size: '6,500 sq ft', features: ['Gift Wrapping'] },
  { id: 4, name: 'Chattogram Agrabad', address: 'Agrabad C/A, Chattogram 4100', city: 'Chattogram', phone: '+880 31-710234', hours: 'Sat-Thu: 10AM-8PM, Fri: 3PM-8PM', isNew: false, isFlagship: false, size: '5,000 sq ft', features: ['Gift Wrapping'] },
  { id: 5, name: 'Sylhet Bondhu Bazar', address: 'Bondhu Bazar, Zindabazar, Sylhet 3100', city: 'Sylhet', phone: '+880 821-710123', hours: 'Sat-Thu: 10AM-8PM, Fri: 3PM-8PM', isNew: false, isFlagship: false, size: '4,500 sq ft', features: ['Gift Wrapping'] },
  { id: 6, name: 'Rajshahi Saheb Bazar', address: 'Saheb Bazar, Rajshahi 6000', city: 'Rajshahi', phone: '+880 721-810234', hours: 'Sat-Thu: 10AM-8PM, Fri: 3PM-8PM', isNew: false, isFlagship: false, size: '4,000 sq ft', features: ['Gift Wrapping'] },
  { id: 7, name: 'Khulna Shib Bari', address: 'Shib Bari Mor, Khulna 9000', city: 'Khulna', phone: '+880 41-710567', hours: 'Sat-Thu: 10AM-8PM, Fri: 3PM-8PM', isNew: false, isFlagship: false, size: '3,500 sq ft', features: [] },
  { id: 8, name: 'Noakhali Maijdee', address: 'Maijdee, Noakhali 3800', city: 'Noakhali', phone: '+880 321-810567', hours: 'Sat-Thu: 10AM-8PM, Fri: 3PM-8PM', isNew: true, isFlagship: false, size: '12,000 sq ft', features: ['TAAGA', 'TAAGA MAN', 'Aarong Earth'] },
];

const cities = Array.from(new Set(stores.map(s => s.city)));

const StoreLocatorPage: React.FC = () => {
  const { setCurrentPage } = useApp();
  const [selectedCity, setSelectedCity] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStore, setSelectedStore] = useState(stores[0]);

  const filteredStores = stores.filter(s =>
    (selectedCity === 'All' || s.city === selectedCity) &&
    (s.name.toLowerCase().includes(searchQuery.toLowerCase()) || s.city.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-[#FAF7F2]">
      {/* Hero */}
      <div className="bg-gradient-to-r from-[#2C1810] to-[#8B4513] py-12 px-8 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-2 text-[#F5E6C8]/60 text-sm mb-4">
            <button onClick={() => setCurrentPage('home')} className="hover:text-[#F5E6C8] transition-colors">Home</button>
            <span>/</span>
            <span className="text-[#F5E6C8]">Store Locator</span>
          </div>
          <h1 className="text-4xl font-light" style={{ fontFamily: 'Georgia, serif' }}>Find an Aarong Store</h1>
          <p className="text-white/70 mt-2">30 stores across Bangladesh — experience handcrafted artistry in person</p>

          <div className="mt-6 flex gap-3 max-w-lg">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40" size={18} />
              <input type="text" placeholder="Search city or store name..." value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-white/10 border border-white/20 text-white placeholder-white/40 rounded-full focus:outline-none focus:border-white/60 backdrop-blur-sm" />
            </div>
            <button className="px-5 py-3 bg-[#C0392B] text-white rounded-full font-medium hover:bg-[#A93226] transition-colors flex items-center gap-2">
              <Navigation size={16} /> Near Me
            </button>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="bg-white border-b border-[#E8D5B0]">
        <div className="max-w-7xl mx-auto px-8 py-4 flex gap-8 overflow-x-auto">
          {[
            { value: '30', label: 'Stores' },
            { value: '9', label: 'Cities' },
            { value: '60K sq ft', label: 'Largest Store (Dhanmondi)' },
            { value: '1978', label: 'First Store Opened' },
          ].map((s, i) => (
            <div key={i} className="flex-shrink-0 text-center px-4 border-r border-[#E8D5B0] last:border-0">
              <p className="font-bold text-[#C0392B] text-xl">{s.value}</p>
              <p className="text-xs text-[#8B4513]">{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 py-8">
        {/* City Filter */}
        <div className="flex gap-2 overflow-x-auto pb-2 mb-6">
          {['All', ...cities].map(city => (
            <button key={city} onClick={() => setSelectedCity(city)}
              className={`flex-shrink-0 px-5 py-2 rounded-full text-sm font-medium transition-all ${selectedCity === city ? 'bg-[#C0392B] text-white shadow-md' : 'bg-white border border-[#E8D5B0] text-[#3D2B1F] hover:border-[#C0392B]'}`}>
              {city}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Store List */}
          <div className="lg:col-span-1 space-y-3 max-h-[700px] overflow-y-auto pr-2">
            {filteredStores.map(store => (
              <button key={store.id} onClick={() => setSelectedStore(store)}
                className={`w-full text-left p-4 bg-white rounded-2xl border-2 transition-all ${selectedStore?.id === store.id ? 'border-[#C0392B] shadow-md' : 'border-[#E8D5B0] hover:border-[#C0392B]/40'}`}>
                <div className="flex items-start justify-between">
                  <div className="flex-1 mr-2">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className="font-semibold text-[#2C1810] text-sm">{store.name}</span>
                      {store.isNew && <span className="px-2 py-0.5 bg-[#27AE60] text-white text-[10px] font-bold rounded-full">NEW</span>}
                      {store.isFlagship && <span className="px-2 py-0.5 bg-[#C0392B] text-white text-[10px] font-bold rounded-full">FLAGSHIP</span>}
                    </div>
                    <p className="text-xs text-[#6B4C3B] flex items-start gap-1"><MapPin size={11} className="flex-shrink-0 mt-0.5" /> {store.address}</p>
                    <p className="text-xs text-[#A07850] mt-1 flex items-center gap-1"><Clock size={11} /> {store.hours.split(',')[0]}</p>
                  </div>
                  <ChevronRight size={16} className={`flex-shrink-0 transition-colors ${selectedStore?.id === store.id ? 'text-[#C0392B]' : 'text-[#C8A87E]'}`} />
                </div>
              </button>
            ))}
          </div>

          {/* Map + Detail */}
          <div className="lg:col-span-2 space-y-4">
            {/* Map Placeholder */}
            <div className="bg-gradient-to-br from-[#E8F5E9] to-[#C8E6C9] rounded-2xl h-72 flex items-center justify-center border border-[#C8E6C9] relative overflow-hidden">
              <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'repeating-linear-gradient(0deg, #2C1810 0, #2C1810 1px, transparent 0, transparent 50px), repeating-linear-gradient(90deg, #2C1810 0, #2C1810 1px, transparent 0, transparent 50px)' }} />
              <div className="text-center">
                <div className="text-5xl mb-3">🗺️</div>
                <p className="font-semibold text-[#2C1810]">{selectedStore?.name}</p>
                <p className="text-sm text-[#6B4C3B]">{selectedStore?.city}, Bangladesh</p>
                <button className="mt-4 px-5 py-2 bg-[#C0392B] text-white rounded-full text-sm font-medium hover:bg-[#A93226] transition-colors flex items-center gap-2 mx-auto">
                  <Navigation size={14} /> Get Directions
                </button>
              </div>
            </div>

            {/* Store Details */}
            {selectedStore && (
              <div className="bg-white rounded-2xl p-6 border border-[#E8D5B0] shadow-sm">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h2 className="font-bold text-[#2C1810] text-lg" style={{ fontFamily: 'Georgia, serif' }}>{selectedStore.name}</h2>
                      {selectedStore.isNew && <span className="px-2 py-0.5 bg-[#27AE60] text-white text-[10px] font-bold rounded-full">NEW</span>}
                      {selectedStore.isFlagship && <span className="px-2 py-0.5 bg-[#C0392B] text-white text-[10px] font-bold rounded-full">FLAGSHIP</span>}
                    </div>
                    <p className="text-sm text-[#6B4C3B]">{selectedStore.size} store</p>
                  </div>
                  <button className="px-4 py-2 bg-[#C0392B] text-white rounded-full text-sm font-medium hover:bg-[#A93226] transition-colors">
                    Get Directions
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="flex items-start gap-3">
                    <MapPin className="text-[#C0392B] flex-shrink-0 mt-1" size={18} />
                    <div>
                      <p className="text-xs font-semibold text-[#8B4513] mb-1">Address</p>
                      <p className="text-sm text-[#3D2B1F]">{selectedStore.address}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Phone className="text-[#C0392B] flex-shrink-0 mt-1" size={18} />
                    <div>
                      <p className="text-xs font-semibold text-[#8B4513] mb-1">Phone</p>
                      <p className="text-sm text-[#3D2B1F]">{selectedStore.phone}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Clock className="text-[#C0392B] flex-shrink-0 mt-1" size={18} />
                    <div>
                      <p className="text-xs font-semibold text-[#8B4513] mb-1">Store Hours</p>
                      <p className="text-sm text-[#3D2B1F]">{selectedStore.hours}</p>
                    </div>
                  </div>
                </div>

                {selectedStore.features.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-[#8B4513] mb-2">In-Store Features</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedStore.features.map(f => (
                        <span key={f} className="px-3 py-1 bg-[#FAF7F2] border border-[#E8D5B0] rounded-full text-xs text-[#3D2B1F] font-medium">
                          {f}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StoreLocatorPage;
