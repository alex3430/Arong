import React, { useState, useMemo } from 'react';
import { X, ChevronDown, ChevronUp, Star, SlidersHorizontal, Grid3x3, LayoutList, ArrowUpDown, Search } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { products, categories } from '../data/products';
import { ProductCard } from './HomePage';

const CategoryPage: React.FC = () => {
  const { selectedCategory, setCurrentPage } = useApp();
  const [sortBy, setSortBy] = useState('newest');
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [gridView, setGridView] = useState<'grid' | 'list'>('grid');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 50000]);
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [onlyInStock, setOnlyInStock] = useState(false);
  const [onlyNew, setOnlyNew] = useState(false);
  const [openFilterSections, setOpenFilterSections] = useState<string[]>(['price', 'color']);
  const [searchFilter, setSearchFilter] = useState('');

  const currentCat = categories.find(c => c.id === selectedCategory);

  const filteredProducts = useMemo(() => {
    let filtered = selectedCategory === 'new-arrivals'
      ? products.filter(p => p.isNew)
      : selectedCategory === 'sale'
        ? products.filter(p => p.originalPrice)
        : products.filter(p => p.category === selectedCategory);

    if (searchFilter) {
      filtered = filtered.filter(p => p.name.toLowerCase().includes(searchFilter.toLowerCase()));
    }
    if (onlyInStock) filtered = filtered.filter(p => p.inStock);
    if (onlyNew) filtered = filtered.filter(p => p.isNew);
    if (selectedColors.length > 0) filtered = filtered.filter(p => p.colors.some(c => selectedColors.includes(c)));
    if (selectedSizes.length > 0) filtered = filtered.filter(p => p.sizes.some(s => selectedSizes.includes(s)));
    filtered = filtered.filter(p => p.price >= priceRange[0] && p.price <= priceRange[1]);

    switch (sortBy) {
      case 'price-low': return [...filtered].sort((a, b) => a.price - b.price);
      case 'price-high': return [...filtered].sort((a, b) => b.price - a.price);
      case 'popular': return [...filtered].sort((a, b) => b.reviews - a.reviews);
      case 'rating': return [...filtered].sort((a, b) => b.rating - a.rating);
      default: return filtered;
    }
  }, [selectedCategory, sortBy, priceRange, selectedColors, selectedSizes, onlyInStock, onlyNew, searchFilter]);

  const allColors = Array.from(new Set(products.flatMap(p => p.colors)));

  const toggleSection = (s: string) => setOpenFilterSections(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);
  const toggleColor = (c: string) => setSelectedColors(prev => prev.includes(c) ? prev.filter(x => x !== c) : [...prev, c]);
  const toggleSize = (s: string) => setSelectedSizes(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);
  const clearFilters = () => { setPriceRange([0, 50000]); setSelectedColors([]); setSelectedSizes([]); setOnlyInStock(false); setOnlyNew(false); };

  const hasActiveFilters = selectedColors.length > 0 || selectedSizes.length > 0 || onlyInStock || onlyNew || priceRange[0] > 0 || priceRange[1] < 50000;

  return (
    <div className="min-h-screen bg-[#FAF7F2]">
      {/* Category Hero */}
      <div className="bg-gradient-to-r from-[#2C1810] to-[#8B4513] py-12 px-8">
        <div className="max-w-7xl mx-auto">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-[#F5E6C8]/60 text-sm mb-4">
            <button onClick={() => setCurrentPage('home')} className="hover:text-[#F5E6C8] transition-colors">Home</button>
            <span>/</span>
            <span className="text-[#F5E6C8]">{currentCat?.label || selectedCategory}</span>
          </div>
          <h1 className="text-4xl font-light text-white" style={{ fontFamily: 'Georgia, serif' }}>
            {currentCat?.label || selectedCategory}
          </h1>
          <p className="text-white/60 mt-2">{filteredProducts.length} handcrafted pieces</p>

          {/* Sub-category tabs */}
          {currentCat && currentCat.subcategories.length > 0 && (
            <div className="flex gap-2 mt-6 overflow-x-auto pb-2">
              <button className="flex-shrink-0 px-4 py-2 bg-white text-[#2C1810] rounded-full text-sm font-semibold">
                All {currentCat.label}
              </button>
              {currentCat.subcategories.map(sub => (
                <button key={sub} className="flex-shrink-0 px-4 py-2 border border-white/40 text-white rounded-full text-sm hover:bg-white/10 transition-colors whitespace-nowrap">
                  {sub}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 py-8">
        {/* Toolbar */}
        <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setFiltersOpen(!filtersOpen)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-full border text-sm font-medium transition-all ${filtersOpen ? 'bg-[#2C1810] text-white border-[#2C1810]' : 'border-[#E8D5B0] text-[#3D2B1F] hover:border-[#2C1810]'}`}
            >
              <SlidersHorizontal size={16} />
              Filters {hasActiveFilters && <span className="w-2 h-2 bg-[#C0392B] rounded-full" />}
            </button>
            {hasActiveFilters && (
              <button onClick={clearFilters} className="flex items-center gap-1 text-xs text-[#C0392B] hover:underline">
                <X size={12} /> Clear All
              </button>
            )}
          </div>

          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#A07850]" size={14} />
              <input
                type="text"
                placeholder="Filter by name..."
                value={searchFilter}
                onChange={e => setSearchFilter(e.target.value)}
                className="pl-9 pr-4 py-2 bg-white border border-[#E8D5B0] rounded-full text-sm focus:outline-none focus:border-[#C0392B] w-48"
              />
            </div>
            <div className="relative">
              <select
                value={sortBy}
                onChange={e => setSortBy(e.target.value)}
                className="appearance-none pl-4 pr-10 py-2.5 bg-white border border-[#E8D5B0] rounded-full text-sm text-[#3D2B1F] focus:outline-none focus:border-[#C0392B] cursor-pointer font-medium"
              >
                <option value="newest">Newest First</option>
                <option value="popular">Most Popular</option>
                <option value="rating">Highest Rated</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
              </select>
              <ArrowUpDown className="absolute right-3 top-1/2 -translate-y-1/2 text-[#A07850]" size={14} />
            </div>
            <div className="flex border border-[#E8D5B0] rounded-full overflow-hidden">
              <button onClick={() => setGridView('grid')} className={`p-2.5 ${gridView === 'grid' ? 'bg-[#2C1810] text-white' : 'bg-white text-[#6B4C3B] hover:bg-[#F0E6D3]'} transition-colors`}>
                <Grid3x3 size={16} />
              </button>
              <button onClick={() => setGridView('list')} className={`p-2.5 ${gridView === 'list' ? 'bg-[#2C1810] text-white' : 'bg-white text-[#6B4C3B] hover:bg-[#F0E6D3]'} transition-colors`}>
                <LayoutList size={16} />
              </button>
            </div>
          </div>
        </div>

        {/* Active filter tags */}
        {hasActiveFilters && (
          <div className="flex flex-wrap gap-2 mb-6">
            {selectedColors.map(c => (
              <span key={c} className="inline-flex items-center gap-1 px-3 py-1 bg-[#F0E6D3] rounded-full text-xs text-[#3D2B1F] font-medium">
                {c} <button onClick={() => toggleColor(c)}><X size={10} /></button>
              </span>
            ))}
            {selectedSizes.map(s => (
              <span key={s} className="inline-flex items-center gap-1 px-3 py-1 bg-[#F0E6D3] rounded-full text-xs text-[#3D2B1F] font-medium">
                {s} <button onClick={() => toggleSize(s)}><X size={10} /></button>
              </span>
            ))}
            {onlyInStock && <span className="inline-flex items-center gap-1 px-3 py-1 bg-[#F0E6D3] rounded-full text-xs text-[#3D2B1F] font-medium">In Stock <button onClick={() => setOnlyInStock(false)}><X size={10} /></button></span>}
          </div>
        )}

        <div className="flex gap-8">
          {/* Filter Sidebar */}
          {filtersOpen && (
            <aside className="w-64 flex-shrink-0 space-y-4">
              {/* Price Range */}
              <div className="bg-white rounded-2xl border border-[#E8D5B0] overflow-hidden">
                <button onClick={() => toggleSection('price')} className="w-full flex items-center justify-between px-5 py-4 font-semibold text-[#2C1810] text-sm">
                  Price Range {openFilterSections.includes('price') ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                </button>
                {openFilterSections.includes('price') && (
                  <div className="px-5 pb-4">
                    <div className="flex justify-between text-xs text-[#8B4513] mb-3">
                      <span>৳{priceRange[0].toLocaleString()}</span>
                      <span>৳{priceRange[1].toLocaleString()}</span>
                    </div>
                    <input type="range" min={0} max={50000} step={500} value={priceRange[1]}
                      onChange={e => setPriceRange([priceRange[0], Number(e.target.value)])}
                      className="w-full accent-[#C0392B]" />
                    <div className="flex gap-2 mt-2">
                      <input type="number" placeholder="Min" value={priceRange[0] || ''}
                        onChange={e => setPriceRange([Number(e.target.value), priceRange[1]])}
                        className="w-1/2 px-3 py-1.5 border border-[#E8D5B0] rounded-lg text-xs focus:outline-none focus:border-[#C0392B]" />
                      <input type="number" placeholder="Max" value={priceRange[1] || ''}
                        onChange={e => setPriceRange([priceRange[0], Number(e.target.value)])}
                        className="w-1/2 px-3 py-1.5 border border-[#E8D5B0] rounded-lg text-xs focus:outline-none focus:border-[#C0392B]" />
                    </div>
                  </div>
                )}
              </div>

              {/* Availability */}
              <div className="bg-white rounded-2xl border border-[#E8D5B0] px-5 py-4 space-y-3">
                <h4 className="font-semibold text-[#2C1810] text-sm">Availability</h4>
                {[
                  { label: 'In Stock', checked: onlyInStock, onChange: () => setOnlyInStock(!onlyInStock) },
                  { label: 'New Arrivals', checked: onlyNew, onChange: () => setOnlyNew(!onlyNew) },
                ].map(opt => (
                  <label key={opt.label} className="flex items-center gap-3 cursor-pointer group">
                    <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all ${opt.checked ? 'bg-[#C0392B] border-[#C0392B]' : 'border-[#C8A87E] group-hover:border-[#C0392B]'}`}
                      onClick={opt.onChange}>
                      {opt.checked && <svg viewBox="0 0 10 8" fill="none" className="w-3 h-3"><path d="M1 4l3 3 5-5.5" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>}
                    </div>
                    <span className="text-sm text-[#3D2B1F]">{opt.label}</span>
                  </label>
                ))}
              </div>

              {/* Color */}
              <div className="bg-white rounded-2xl border border-[#E8D5B0] overflow-hidden">
                <button onClick={() => toggleSection('color')} className="w-full flex items-center justify-between px-5 py-4 font-semibold text-[#2C1810] text-sm">
                  Color {openFilterSections.includes('color') ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                </button>
                {openFilterSections.includes('color') && (
                  <div className="px-5 pb-4 flex flex-wrap gap-2">
                    {allColors.slice(0, 10).map(c => (
                      <button key={c} onClick={() => toggleColor(c)}
                        className={`px-3 py-1 rounded-full text-xs border transition-all ${selectedColors.includes(c) ? 'bg-[#C0392B] text-white border-[#C0392B]' : 'border-[#E8D5B0] text-[#3D2B1F] hover:border-[#C0392B]'}`}>
                        {c}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Size */}
              <div className="bg-white rounded-2xl border border-[#E8D5B0] overflow-hidden">
                <button onClick={() => toggleSection('size')} className="w-full flex items-center justify-between px-5 py-4 font-semibold text-[#2C1810] text-sm">
                  Size {openFilterSections.includes('size') ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                </button>
                {openFilterSections.includes('size') && (
                  <div className="px-5 pb-4 flex flex-wrap gap-2">
                    {['XS', 'S', 'M', 'L', 'XL', 'XXL', 'Free Size'].map(s => (
                      <button key={s} onClick={() => toggleSize(s)}
                        className={`px-3 py-1.5 rounded-lg text-xs border font-medium transition-all ${selectedSizes.includes(s) ? 'bg-[#2C1810] text-white border-[#2C1810]' : 'border-[#E8D5B0] text-[#3D2B1F] hover:border-[#2C1810]'}`}>
                        {s}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Rating */}
              <div className="bg-white rounded-2xl border border-[#E8D5B0] px-5 py-4">
                <h4 className="font-semibold text-[#2C1810] text-sm mb-3">Minimum Rating</h4>
                {[4.5, 4, 3.5, 3].map(r => (
                  <label key={r} className="flex items-center gap-2 cursor-pointer py-1">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map(star => (
                        <Star key={star} size={14} className={star <= r ? 'text-[#F39C12] fill-[#F39C12]' : 'text-[#E8D5B0]'} />
                      ))}
                    </div>
                    <span className="text-xs text-[#6B4C3B]">& above</span>
                  </label>
                ))}
              </div>
            </aside>
          )}

          {/* Product Grid */}
          <div className="flex-1">
            <p className="text-sm text-[#8B4513] mb-4">{filteredProducts.length} products found</p>
            {filteredProducts.length === 0 ? (
              <div className="text-center py-20">
                <div className="text-5xl mb-4">🔍</div>
                <h3 className="text-xl font-semibold text-[#2C1810] mb-2">No products found</h3>
                <p className="text-[#8B4513] mb-4">Try adjusting your filters</p>
                <button onClick={clearFilters} className="px-6 py-3 bg-[#C0392B] text-white rounded-full text-sm font-medium">
                  Clear Filters
                </button>
              </div>
            ) : (
              <div className={`grid gap-4 md:gap-6 ${filtersOpen ? 'grid-cols-2 md:grid-cols-3' : 'grid-cols-2 md:grid-cols-4'}`}>
                {filteredProducts.map(p => <ProductCard key={p.id} product={p} />)}
              </div>
            )}

            {/* Pagination */}
            {filteredProducts.length > 0 && (
              <div className="flex justify-center items-center gap-2 mt-12">
                <button className="px-4 py-2 border border-[#E8D5B0] rounded-full text-sm text-[#6B4C3B] hover:border-[#C0392B] transition-colors">← Prev</button>
                {[1, 2, 3, '...', 8].map((p, i) => (
                  <button key={i} className={`w-9 h-9 rounded-full text-sm font-medium transition-colors ${p === 1 ? 'bg-[#C0392B] text-white' : 'border border-[#E8D5B0] text-[#6B4C3B] hover:border-[#C0392B]'}`}>
                    {p}
                  </button>
                ))}
                <button className="px-4 py-2 border border-[#E8D5B0] rounded-full text-sm text-[#6B4C3B] hover:border-[#C0392B] transition-colors">Next →</button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CategoryPage;
