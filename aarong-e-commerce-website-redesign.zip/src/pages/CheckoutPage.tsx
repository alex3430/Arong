import React, { useState } from 'react';
import { Check, CreditCard, Smartphone, Banknote, Lock, ArrowLeft, ChevronRight, Truck, MapPin, Clock } from 'lucide-react';
import { useApp } from '../context/AppContext';

type Step = 'info' | 'shipping' | 'payment' | 'review' | 'confirmed';

const CheckoutPage: React.FC = () => {
  const { cart, cartTotal, discount, appliedCoupon, clearCart, setCurrentPage, isLoggedIn } = useApp();
  const [step, setStep] = useState<Step>(isLoggedIn ? 'info' : 'info');
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [deliveryOption, setDeliveryOption] = useState('standard');
  const [form, setForm] = useState({
    firstName: '', lastName: '', email: '', phone: '',
    address: '', city: 'Dhaka', district: '', postalCode: '',
    cardNumber: '', cardExpiry: '', cardCvv: '', cardName: '',
    bkashNumber: '', nagadNumber: '',
  });
  const [orderPlaced, setOrderPlaced] = useState(false);

  const discountAmount = cartTotal * discount;
  const deliveryCost = deliveryOption === 'express' ? 250 : deliveryOption === 'same-day' ? 400 : (cartTotal > 3000 ? 0 : 120);
  const finalTotal = cartTotal - discountAmount + deliveryCost;

  const orderId = `ARG-${Date.now().toString().slice(-8)}`;

  const steps = [
    { id: 'info', label: 'Contact', icon: '👤' },
    { id: 'shipping', label: 'Shipping', icon: '📦' },
    { id: 'payment', label: 'Payment', icon: '💳' },
    { id: 'review', label: 'Review', icon: '✓' },
  ];

  const handlePlaceOrder = () => {
    setStep('confirmed');
    setOrderPlaced(true);
    setTimeout(() => clearCart(), 500);
  };

  if (orderPlaced && step === 'confirmed') {
    return (
      <div className="min-h-screen bg-[#FAF7F2] flex items-center justify-center px-4">
        <div className="max-w-lg w-full text-center bg-white rounded-3xl shadow-xl p-12 border border-[#E8D5B0]">
          <div className="w-20 h-20 bg-[#27AE60] rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
            <Check className="text-white" size={36} />
          </div>
          <h1 className="text-3xl font-bold text-[#2C1810] mb-2" style={{ fontFamily: 'Georgia, serif' }}>Order Placed! 🎉</h1>
          <p className="text-[#6B4C3B] mb-6">Thank you for choosing Aarong. Your handcrafted items are being prepared with love.</p>
          <div className="bg-[#FAF7F2] rounded-2xl p-5 mb-6 border border-[#E8D5B0] text-left">
            <p className="text-xs text-[#A07850] mb-1">Order ID</p>
            <p className="font-bold text-[#2C1810] text-lg">{orderId}</p>
            <p className="text-xs text-[#8B4513] mt-3">📧 Confirmation sent to {form.email || 'your email'}</p>
            <p className="text-xs text-[#8B4513] mt-1">🚚 Expected delivery in {deliveryOption === 'same-day' ? '1 day' : deliveryOption === 'express' ? '1-2 days' : '3-5 days'}</p>
          </div>
          <div className="flex flex-col gap-3">
            <button onClick={() => setCurrentPage('account')} className="w-full py-3 bg-[#C0392B] text-white rounded-full font-semibold hover:bg-[#A93226] transition-colors">
              Track Your Order
            </button>
            <button onClick={() => setCurrentPage('home')} className="w-full py-3 border border-[#E8D5B0] rounded-full font-semibold text-[#3D2B1F] hover:border-[#C0392B] transition-colors">
              Continue Shopping
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAF7F2]">
      {/* Header */}
      <div className="bg-white border-b border-[#E8D5B0] px-4 md:px-8 py-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <button onClick={() => setCurrentPage('home')} className="flex items-center gap-2 text-[#3D2B1F] hover:text-[#C0392B] transition-colors">
            <ArrowLeft size={20} />
            <span className="font-bold text-xl" style={{ fontFamily: 'Georgia, serif' }}>Aarong</span>
          </button>
          <h1 className="font-semibold text-[#2C1810]">Secure Checkout</h1>
          <Lock className="text-[#27AE60]" size={20} />
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 md:px-8 py-8">
        {/* Progress Steps */}
        <div className="flex items-center justify-center mb-10">
          {steps.map((s, i) => {
            const stepIdx = steps.findIndex(x => x.id === step);
            const isCompleted = i < stepIdx;
            const isCurrent = s.id === step;
            return (
              <React.Fragment key={s.id}>
                <div className="flex flex-col items-center">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold transition-all ${isCompleted ? 'bg-[#27AE60] text-white' : isCurrent ? 'bg-[#C0392B] text-white' : 'bg-[#E8D5B0] text-[#A07850]'}`}>
                    {isCompleted ? <Check size={18} /> : s.icon}
                  </div>
                  <span className={`text-xs mt-1 font-medium ${isCurrent ? 'text-[#C0392B]' : isCompleted ? 'text-[#27AE60]' : 'text-[#A07850]'}`}>{s.label}</span>
                </div>
                {i < steps.length - 1 && (
                  <div className={`flex-1 h-0.5 mx-2 mb-4 ${i < stepIdx ? 'bg-[#27AE60]' : 'bg-[#E8D5B0]'}`} />
                )}
              </React.Fragment>
            );
          })}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Main Form */}
          <div className="md:col-span-2 space-y-6">

            {/* Step 1: Contact Info */}
            {step === 'info' && (
              <div className="bg-white rounded-2xl p-6 border border-[#E8D5B0] shadow-sm">
                <h2 className="font-bold text-[#2C1810] text-lg mb-5 flex items-center gap-2">👤 Contact Information</h2>
                {!isLoggedIn && (
                  <div className="bg-[#FAF7F2] rounded-xl p-4 mb-5 border border-[#E8D5B0]">
                    <p className="text-sm text-[#6B4C3B]">Already have an account?
                      <button onClick={() => setCurrentPage('auth')} className="text-[#C0392B] font-semibold ml-1 hover:underline">Sign In</button>
                      {' '}for faster checkout & points
                    </p>
                  </div>
                )}
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { label: 'First Name', key: 'firstName', placeholder: 'Nadia' },
                    { label: 'Last Name', key: 'lastName', placeholder: 'Islam' },
                  ].map(f => (
                    <div key={f.key}>
                      <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">{f.label} *</label>
                      <input type="text" placeholder={f.placeholder} value={form[f.key as keyof typeof form]}
                        onChange={e => setForm({ ...form, [f.key]: e.target.value })}
                        className="w-full px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B] transition-colors" />
                    </div>
                  ))}
                  <div>
                    <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">Email Address *</label>
                    <input type="email" placeholder="nadia@example.com" value={form.email}
                      onChange={e => setForm({ ...form, email: e.target.value })}
                      className="w-full px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B] transition-colors" />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">Phone Number *</label>
                    <input type="tel" placeholder="+880 1X..." value={form.phone}
                      onChange={e => setForm({ ...form, phone: e.target.value })}
                      className="w-full px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B] transition-colors" />
                  </div>
                </div>
                <button onClick={() => setStep('shipping')}
                  className="mt-6 w-full py-4 bg-[#C0392B] text-white rounded-full font-semibold hover:bg-[#A93226] transition-colors flex items-center justify-center gap-2">
                  Continue to Shipping <ChevronRight size={18} />
                </button>
              </div>
            )}

            {/* Step 2: Shipping */}
            {step === 'shipping' && (
              <div className="bg-white rounded-2xl p-6 border border-[#E8D5B0] shadow-sm">
                <h2 className="font-bold text-[#2C1810] text-lg mb-5 flex items-center gap-2"><MapPin size={20} className="text-[#C0392B]" /> Shipping Address</h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">Full Address *</label>
                    <input type="text" placeholder="House #, Road #, Area..." value={form.address}
                      onChange={e => setForm({ ...form, address: e.target.value })}
                      className="w-full px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B]" />
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">City</label>
                      <select value={form.city} onChange={e => setForm({ ...form, city: e.target.value })}
                        className="w-full px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B]">
                        {['Dhaka', 'Chattogram', 'Sylhet', 'Rajshahi', 'Khulna', 'Barishal'].map(c => <option key={c}>{c}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">District</label>
                      <input type="text" placeholder="District" value={form.district}
                        onChange={e => setForm({ ...form, district: e.target.value })}
                        className="w-full px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B]" />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">Postal Code</label>
                      <input type="text" placeholder="1212" value={form.postalCode}
                        onChange={e => setForm({ ...form, postalCode: e.target.value })}
                        className="w-full px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B]" />
                    </div>
                  </div>
                </div>

                {/* Delivery Options */}
                <div className="mt-6">
                  <h3 className="font-semibold text-[#2C1810] mb-4 flex items-center gap-2"><Truck size={18} className="text-[#C0392B]" /> Delivery Options</h3>
                  <div className="space-y-3">
                    {[
                      { id: 'standard', icon: <Truck size={18} />, title: 'Standard Delivery', sub: '3-5 business days', price: cartTotal > 3000 ? 'FREE' : '৳120' },
                      { id: 'express', icon: <Clock size={18} />, title: 'Express Delivery', sub: '1-2 business days', price: '৳250' },
                      { id: 'same-day', icon: <Truck size={18} />, title: 'Same Day Delivery', sub: 'Dhaka only (order before 12 PM)', price: '৳400' },
                    ].map(opt => (
                      <label key={opt.id} className={`flex items-center gap-4 p-4 border-2 rounded-xl cursor-pointer transition-all ${deliveryOption === opt.id ? 'border-[#C0392B] bg-[#FEF5F3]' : 'border-[#E8D5B0] hover:border-[#C0392B]/50'}`}>
                        <input type="radio" name="delivery" value={opt.id} checked={deliveryOption === opt.id} onChange={() => setDeliveryOption(opt.id)} className="sr-only" />
                        <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${deliveryOption === opt.id ? 'border-[#C0392B]' : 'border-[#C8A87E]'}`}>
                          {deliveryOption === opt.id && <div className="w-2.5 h-2.5 bg-[#C0392B] rounded-full" />}
                        </div>
                        <div className="text-[#6B4C3B]">{opt.icon}</div>
                        <div className="flex-1">
                          <p className="font-semibold text-[#2C1810] text-sm">{opt.title}</p>
                          <p className="text-xs text-[#8B4513]">{opt.sub}</p>
                        </div>
                        <span className={`font-bold text-sm ${opt.price === 'FREE' ? 'text-[#27AE60]' : 'text-[#2C1810]'}`}>{opt.price}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="flex gap-3 mt-6">
                  <button onClick={() => setStep('info')} className="px-6 py-3 border border-[#E8D5B0] rounded-full text-sm font-semibold text-[#6B4C3B] hover:border-[#C0392B] transition-colors flex items-center gap-1">
                    <ArrowLeft size={16} /> Back
                  </button>
                  <button onClick={() => setStep('payment')} className="flex-1 py-4 bg-[#C0392B] text-white rounded-full font-semibold hover:bg-[#A93226] transition-colors flex items-center justify-center gap-2">
                    Continue to Payment <ChevronRight size={18} />
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Payment */}
            {step === 'payment' && (
              <div className="bg-white rounded-2xl p-6 border border-[#E8D5B0] shadow-sm">
                <h2 className="font-bold text-[#2C1810] text-lg mb-5 flex items-center gap-2"><Lock size={18} className="text-[#27AE60]" /> Secure Payment</h2>

                {/* Payment method selection */}
                <div className="grid grid-cols-3 gap-3 mb-6">
                  {[
                    { id: 'card', icon: <CreditCard size={22} />, label: 'Card' },
                    { id: 'mobile', icon: <Smartphone size={22} />, label: 'Mobile Banking' },
                    { id: 'cod', icon: <Banknote size={22} />, label: 'Cash on Delivery' },
                  ].map(m => (
                    <button key={m.id} onClick={() => setPaymentMethod(m.id)}
                      className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${paymentMethod === m.id ? 'border-[#C0392B] bg-[#FEF5F3] text-[#C0392B]' : 'border-[#E8D5B0] text-[#6B4C3B] hover:border-[#C0392B]/50'}`}>
                      {m.icon}
                      <span className="text-xs font-semibold">{m.label}</span>
                    </button>
                  ))}
                </div>

                {paymentMethod === 'card' && (
                  <div className="space-y-4">
                    <div className="flex gap-2 mb-3">
                      {['VISA', 'MC', 'AMEX'].map(b => (
                        <span key={b} className="px-3 py-1 bg-[#FAF7F2] border border-[#E8D5B0] rounded text-xs font-bold text-[#3D2B1F]">{b}</span>
                      ))}
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">Card Number</label>
                      <input type="text" placeholder="1234 5678 9012 3456" value={form.cardNumber}
                        onChange={e => setForm({ ...form, cardNumber: e.target.value })}
                        className="w-full px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B]" />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">Cardholder Name</label>
                      <input type="text" placeholder="Nadia Islam" value={form.cardName}
                        onChange={e => setForm({ ...form, cardName: e.target.value })}
                        className="w-full px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B]" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">Expiry Date</label>
                        <input type="text" placeholder="MM/YY" value={form.cardExpiry}
                          onChange={e => setForm({ ...form, cardExpiry: e.target.value })}
                          className="w-full px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B]" />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">CVV</label>
                        <input type="password" placeholder="•••" value={form.cardCvv}
                          onChange={e => setForm({ ...form, cardCvv: e.target.value })}
                          className="w-full px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B]" />
                      </div>
                    </div>
                  </div>
                )}

                {paymentMethod === 'mobile' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-3">
                      {['bKash', 'Nagad', 'Rocket', 'SureCash'].map(m => (
                        <button key={m} className="p-4 border border-[#E8D5B0] rounded-xl text-sm font-semibold text-[#3D2B1F] hover:border-[#C0392B] transition-colors">{m}</button>
                      ))}
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">Mobile Banking Number</label>
                      <input type="tel" placeholder="+880 1X..." value={form.bkashNumber}
                        onChange={e => setForm({ ...form, bkashNumber: e.target.value })}
                        className="w-full px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B]" />
                    </div>
                  </div>
                )}

                {paymentMethod === 'cod' && (
                  <div className="bg-[#FAF7F2] rounded-xl p-5 border border-[#E8D5B0]">
                    <p className="text-sm text-[#6B4C3B] flex items-start gap-2">
                      <Banknote size={18} className="text-[#27AE60] flex-shrink-0 mt-0.5" />
                      Pay in cash when your order arrives. Available for orders under ৳20,000. Our delivery partner will contact you before delivery.
                    </p>
                  </div>
                )}

                <div className="flex gap-3 mt-6">
                  <button onClick={() => setStep('shipping')} className="px-6 py-3 border border-[#E8D5B0] rounded-full text-sm font-semibold text-[#6B4C3B] hover:border-[#C0392B] transition-colors flex items-center gap-1">
                    <ArrowLeft size={16} /> Back
                  </button>
                  <button onClick={() => setStep('review')} className="flex-1 py-4 bg-[#C0392B] text-white rounded-full font-semibold hover:bg-[#A93226] transition-colors flex items-center justify-center gap-2">
                    Review Order <ChevronRight size={18} />
                  </button>
                </div>
              </div>
            )}

            {/* Step 4: Review */}
            {step === 'review' && (
              <div className="bg-white rounded-2xl p-6 border border-[#E8D5B0] shadow-sm">
                <h2 className="font-bold text-[#2C1810] text-lg mb-5">✓ Order Review</h2>
                <div className="space-y-3 mb-6">
                  {cart.map(item => (
                    <div key={item.id} className="flex gap-3 p-3 bg-[#FAF7F2] rounded-xl border border-[#E8D5B0]">
                      <img src={item.images[0]} alt={item.name} className="w-14 h-14 rounded-lg object-cover" />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-[#2C1810]">{item.name}</p>
                        <p className="text-xs text-[#8B4513]">{item.selectedColor} · {item.selectedSize} · Qty: {item.quantity}</p>
                        <p className="text-sm font-bold text-[#C0392B]">৳{(item.price * item.quantity).toLocaleString()}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-[#FAF7F2] rounded-xl p-4 border border-[#E8D5B0] mb-6 space-y-2 text-sm">
                  {[
                    { label: 'Subtotal', value: `৳${cartTotal.toLocaleString()}` },
                    discount > 0 && { label: `Discount (${appliedCoupon})`, value: `-৳${(cartTotal * discount).toFixed(0)}`, green: true },
                    { label: 'Delivery', value: deliveryCost === 0 ? 'FREE' : `৳${deliveryCost}`, green: deliveryCost === 0 },
                    { label: 'Total', value: `৳${finalTotal.toLocaleString()}`, bold: true },
                  ].filter(Boolean).map((row: any, i) => (
                    <div key={i} className={`flex justify-between ${row.bold ? 'font-bold text-base border-t border-[#E8D5B0] pt-2' : ''}`}>
                      <span className="text-[#6B4C3B]">{row.label}</span>
                      <span className={row.green ? 'text-[#27AE60]' : row.bold ? 'text-[#C0392B]' : 'text-[#2C1810]'}>{row.value}</span>
                    </div>
                  ))}
                </div>

                <div className="flex items-start gap-3 mb-6 p-3 bg-[#E8F5E9] rounded-xl">
                  <Lock size={16} className="text-[#27AE60] flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-[#2E7D32]">Your payment is secured with 256-bit SSL encryption. Aarong does not store your card details.</p>
                </div>

                <div className="flex gap-3">
                  <button onClick={() => setStep('payment')} className="px-6 py-3 border border-[#E8D5B0] rounded-full text-sm font-semibold text-[#6B4C3B] hover:border-[#C0392B] transition-colors flex items-center gap-1">
                    <ArrowLeft size={16} /> Back
                  </button>
                  <button onClick={handlePlaceOrder} className="flex-1 py-4 bg-[#C0392B] text-white rounded-full font-semibold hover:bg-[#A93226] transition-all flex items-center justify-center gap-2 text-base shadow-lg hover:shadow-xl">
                    <Lock size={18} /> Place Order — ৳{finalTotal.toLocaleString()}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Order Summary Sidebar */}
          <div className="space-y-4">
            <div className="bg-white rounded-2xl p-5 border border-[#E8D5B0] shadow-sm sticky top-4">
              <h3 className="font-bold text-[#2C1810] mb-4">Order Summary</h3>
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {cart.map(item => (
                  <div key={item.id} className="flex gap-2">
                    <div className="relative">
                      <img src={item.images[0]} alt={item.name} className="w-12 h-12 rounded-lg object-cover" />
                      <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#2C1810] text-white text-[10px] rounded-full flex items-center justify-center font-bold">{item.quantity}</span>
                    </div>
                    <div>
                      <p className="text-xs font-medium text-[#2C1810] line-clamp-1">{item.name}</p>
                      <p className="text-xs text-[#C0392B] font-bold">৳{(item.price * item.quantity).toLocaleString()}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="border-t border-[#E8D5B0] mt-4 pt-4 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-[#6B4C3B]">Subtotal</span>
                  <span className="text-[#2C1810] font-medium">৳{cartTotal.toLocaleString()}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between">
                    <span className="text-[#27AE60]">Discount</span>
                    <span className="text-[#27AE60]">-৳{(cartTotal * discount).toFixed(0)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-[#6B4C3B]">Delivery</span>
                  <span className={deliveryCost === 0 ? 'text-[#27AE60] font-medium' : 'text-[#2C1810] font-medium'}>{deliveryCost === 0 ? 'FREE' : `৳${deliveryCost}`}</span>
                </div>
                <div className="flex justify-between font-bold text-base border-t border-[#E8D5B0] pt-2">
                  <span className="text-[#2C1810]">Total</span>
                  <span className="text-[#C0392B]">৳{finalTotal.toLocaleString()}</span>
                </div>
              </div>

              <div className="mt-4 space-y-2">
                <div className="flex items-center gap-2 text-xs text-[#6B4C3B]"><Check size={12} className="text-[#27AE60]" /> 100% Secure & Encrypted</div>
                <div className="flex items-center gap-2 text-xs text-[#6B4C3B]"><Check size={12} className="text-[#27AE60]" /> 7-day easy returns</div>
                <div className="flex items-center gap-2 text-xs text-[#6B4C3B]"><Check size={12} className="text-[#27AE60]" /> Authentic artisan products</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
