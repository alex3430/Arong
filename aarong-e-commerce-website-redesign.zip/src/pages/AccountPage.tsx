import React, { useState } from 'react';
import { User, Package, Heart, MapPin, Lock, Award, ChevronRight, Star, TrendingUp, Bell, LogOut, Edit3, Check } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { products } from '../data/products';

const mockOrders = [
  { id: 'ARG-20241201', date: 'Dec 1, 2024', status: 'Delivered', total: 12500, items: 2, product: products[0] },
  { id: 'ARG-20241115', date: 'Nov 15, 2024', status: 'Processing', total: 5200, items: 1, product: products[2] },
  { id: 'ARG-20241005', date: 'Oct 5, 2024', status: 'Delivered', total: 8500, items: 3, product: products[7] },
];

const statusColors: Record<string, string> = {
  Delivered: 'bg-[#E8F5E9] text-[#2E7D32]',
  Processing: 'bg-[#FFF8E1] text-[#F57F17]',
  Shipped: 'bg-[#E3F2FD] text-[#1565C0]',
  Cancelled: 'bg-[#FDECEA] text-[#B71C1C]',
};

const AccountPage: React.FC = () => {
  const { isLoggedIn, setIsLoggedIn, user, setCurrentPage, wishlist } = useApp();
  const [activeSection, setActiveSection] = useState('overview');
  const [editMode, setEditMode] = useState(false);

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-[#FAF7F2] flex items-center justify-center px-4">
        <div className="max-w-md w-full bg-white rounded-3xl shadow-xl p-10 border border-[#E8D5B0] text-center">
          <div className="w-20 h-20 bg-[#F0E6D3] rounded-full flex items-center justify-center mx-auto mb-6">
            <User className="text-[#C0392B]" size={36} />
          </div>
          <h2 className="text-2xl font-bold text-[#2C1810] mb-2" style={{ fontFamily: 'Georgia, serif' }}>Welcome Back</h2>
          <p className="text-[#6B4C3B] mb-8">Sign in to access your account, orders, and wishlist</p>
          <button onClick={() => setCurrentPage('auth')} className="w-full py-4 bg-[#C0392B] text-white rounded-full font-semibold hover:bg-[#A93226] transition-colors mb-3">
            Sign In
          </button>
          <button onClick={() => setCurrentPage('auth')} className="w-full py-4 border border-[#E8D5B0] rounded-full font-semibold text-[#3D2B1F] hover:border-[#C0392B] transition-colors">
            Create Account
          </button>
        </div>
      </div>
    );
  }

  const navItems = [
    { id: 'overview', label: 'Overview', icon: <TrendingUp size={18} /> },
    { id: 'orders', label: 'My Orders', icon: <Package size={18} /> },
    { id: 'wishlist', label: 'Wishlist', icon: <Heart size={18} /> },
    { id: 'addresses', label: 'Addresses', icon: <MapPin size={18} /> },
    { id: 'loyalty', label: 'Loyalty & Rewards', icon: <Award size={18} /> },
    { id: 'notifications', label: 'Notifications', icon: <Bell size={18} /> },
    { id: 'security', label: 'Password & Security', icon: <Lock size={18} /> },
  ];

  return (
    <div className="min-h-screen bg-[#FAF7F2]">
      {/* Account Header */}
      <div className="bg-gradient-to-r from-[#2C1810] to-[#8B4513] py-10 px-8">
        <div className="max-w-7xl mx-auto flex items-center gap-6">
          <div className="w-16 h-16 bg-[#C0392B] rounded-full flex items-center justify-center text-white text-2xl font-bold shadow-lg">
            {user?.name.charAt(0)}
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white" style={{ fontFamily: 'Georgia, serif' }}>Hello, {user?.name}!</h1>
            <p className="text-white/70 text-sm">{user?.email}</p>
            <div className="flex items-center gap-2 mt-2">
              <span className="px-3 py-1 bg-[#F5E6C8]/20 text-[#F5E6C8] rounded-full text-xs font-semibold">
                ✦ Gold Member
              </span>
              <span className="text-[#F5E6C8]/80 text-xs">{user?.points.toLocaleString()} points</span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 py-8 flex gap-8">
        {/* Sidebar */}
        <aside className="w-56 flex-shrink-0 space-y-1">
          {navItems.map(item => (
            <button key={item.id} onClick={() => setActiveSection(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${activeSection === item.id ? 'bg-[#C0392B] text-white shadow-md' : 'text-[#3D2B1F] hover:bg-[#F0E6D3]'}`}>
              {item.icon} {item.label}
            </button>
          ))}
          <button onClick={() => { setIsLoggedIn(false); setCurrentPage('home'); }}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-[#C0392B] hover:bg-[#FDECEA] transition-all mt-4">
            <LogOut size={18} /> Sign Out
          </button>
        </aside>

        {/* Main Content */}
        <div className="flex-1">
          {/* Overview */}
          {activeSection === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-3 gap-4">
                {[
                  { label: 'Total Orders', value: mockOrders.length, icon: <Package size={22} className="text-[#C0392B]" />, bg: 'bg-[#FDECEA]' },
                  { label: 'Wishlist Items', value: wishlist.length, icon: <Heart size={22} className="text-[#E91E63]" />, bg: 'bg-[#FCE4EC]' },
                  { label: 'Loyalty Points', value: `${user?.points?.toLocaleString()}`, icon: <Award size={22} className="text-[#F39C12]" />, bg: 'bg-[#FFF8E1]' },
                ].map((stat, i) => (
                  <div key={i} className="bg-white rounded-2xl p-5 border border-[#E8D5B0] shadow-sm">
                    <div className={`w-10 h-10 ${stat.bg} rounded-xl flex items-center justify-center mb-3`}>{stat.icon}</div>
                    <div className="text-2xl font-bold text-[#2C1810]">{stat.value}</div>
                    <div className="text-xs text-[#8B4513]">{stat.label}</div>
                  </div>
                ))}
              </div>

              {/* Profile */}
              <div className="bg-white rounded-2xl p-6 border border-[#E8D5B0] shadow-sm">
                <div className="flex items-center justify-between mb-5">
                  <h3 className="font-bold text-[#2C1810]">Personal Information</h3>
                  <button onClick={() => setEditMode(!editMode)} className="flex items-center gap-1 text-sm text-[#C0392B] hover:underline">
                    {editMode ? <><Check size={14} /> Save</> : <><Edit3 size={14} /> Edit</>}
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { label: 'Full Name', value: user?.name },
                    { label: 'Email', value: user?.email },
                    { label: 'Phone', value: '+880 1700 000000' },
                    { label: 'Date of Birth', value: 'Jan 15, 1990' },
                    { label: 'Gender', value: 'Female' },
                    { label: 'Member Since', value: 'March 2020' },
                  ].map(field => (
                    <div key={field.label}>
                      <p className="text-xs text-[#A07850] mb-1">{field.label}</p>
                      {editMode ? (
                        <input defaultValue={field.value} className="w-full px-3 py-2 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B]" />
                      ) : (
                        <p className="text-sm font-medium text-[#2C1810]">{field.value}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Recent Orders */}
              <div className="bg-white rounded-2xl p-6 border border-[#E8D5B0] shadow-sm">
                <div className="flex items-center justify-between mb-5">
                  <h3 className="font-bold text-[#2C1810]">Recent Orders</h3>
                  <button onClick={() => setActiveSection('orders')} className="text-sm text-[#C0392B] hover:underline flex items-center gap-1">View All <ChevronRight size={14} /></button>
                </div>
                <div className="space-y-3">
                  {mockOrders.slice(0, 2).map(order => (
                    <div key={order.id} className="flex items-center gap-4 p-3 bg-[#FAF7F2] rounded-xl border border-[#E8D5B0]">
                      <img src={order.product.images[0]} alt={order.product.name} className="w-12 h-12 rounded-lg object-cover" />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-[#2C1810]">{order.id}</p>
                        <p className="text-xs text-[#8B4513]">{order.date} · {order.items} item(s)</p>
                      </div>
                      <div className="text-right">
                        <span className={`text-xs font-semibold px-2 py-1 rounded-full ${statusColors[order.status]}`}>{order.status}</span>
                        <p className="text-sm font-bold text-[#C0392B] mt-1">৳{order.total.toLocaleString()}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Orders */}
          {activeSection === 'orders' && (
            <div className="bg-white rounded-2xl p-6 border border-[#E8D5B0] shadow-sm">
              <h3 className="font-bold text-[#2C1810] text-lg mb-5">My Orders</h3>
              <div className="space-y-4">
                {mockOrders.map(order => (
                  <div key={order.id} className="border border-[#E8D5B0] rounded-2xl overflow-hidden">
                    <div className="flex items-center justify-between px-5 py-3 bg-[#FAF7F2]">
                      <div>
                        <span className="text-xs text-[#A07850]">Order ID: </span>
                        <span className="text-sm font-bold text-[#2C1810]">{order.id}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className={`text-xs font-semibold px-3 py-1 rounded-full ${statusColors[order.status]}`}>{order.status}</span>
                        <span className="text-sm font-bold text-[#C0392B]">৳{order.total.toLocaleString()}</span>
                      </div>
                    </div>
                    <div className="p-5 flex items-center gap-4">
                      <img src={order.product.images[0]} alt={order.product.name} className="w-16 h-16 rounded-xl object-cover" />
                      <div className="flex-1">
                        <p className="font-medium text-[#2C1810]">{order.product.name}</p>
                        <p className="text-xs text-[#8B4513] mt-1">Placed on {order.date} · {order.items} item(s)</p>
                      </div>
                      <div className="flex gap-2">
                        {order.status === 'Delivered' && (
                          <button className="px-4 py-2 border border-[#E8D5B0] rounded-full text-xs font-medium text-[#3D2B1F] hover:border-[#C0392B] transition-colors flex items-center gap-1">
                            <Star size={12} /> Write Review
                          </button>
                        )}
                        <button className="px-4 py-2 border border-[#C0392B] text-[#C0392B] rounded-full text-xs font-medium hover:bg-[#C0392B] hover:text-white transition-all">
                          Track Order
                        </button>
                      </div>
                    </div>

                    {/* Tracking */}
                    {order.status === 'Processing' && (
                      <div className="px-5 pb-5">
                        <div className="flex items-center gap-0">
                          {['Order Placed', 'Confirmed', 'Packaging', 'Shipped', 'Delivered'].map((s, i) => (
                            <React.Fragment key={s}>
                              <div className="flex flex-col items-center">
                                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] ${i < 2 ? 'bg-[#27AE60] text-white' : 'bg-[#E8D5B0] text-[#A07850]'}`}>
                                  {i < 2 ? <Check size={10} /> : i + 1}
                                </div>
                                <span className="text-[9px] text-[#8B4513] mt-1 text-center w-14">{s}</span>
                              </div>
                              {i < 4 && <div className={`flex-1 h-0.5 mb-4 ${i < 1 ? 'bg-[#27AE60]' : 'bg-[#E8D5B0]'}`} />}
                            </React.Fragment>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Loyalty */}
          {activeSection === 'loyalty' && (
            <div className="space-y-6">
              <div className="bg-gradient-to-br from-[#2C1810] to-[#8B4513] rounded-2xl p-8 text-white">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <p className="text-[#F5E6C8]/70 text-sm">Loyalty Status</p>
                    <h2 className="text-3xl font-bold" style={{ fontFamily: 'Georgia, serif' }}>✦ Gold Member</h2>
                  </div>
                  <div className="text-right">
                    <p className="text-[#F5E6C8]/70 text-sm">Available Points</p>
                    <p className="text-4xl font-bold">{user?.points.toLocaleString()}</p>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-xs text-[#F5E6C8]/70 mb-2">
                    <span>Gold</span>
                    <span>Platinum ({(5000 - (user?.points || 0)).toLocaleString()} pts away)</span>
                  </div>
                  <div className="h-3 bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-[#F5E6C8] to-[#C0392B] rounded-full" style={{ width: `${Math.min(((user?.points || 0) / 5000) * 100, 100)}%` }} />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                {[
                  { label: 'Points Earned', value: '4,250', sub: 'All time' },
                  { label: 'Points Redeemed', value: '1,800', sub: 'Saved ৳180' },
                  { label: 'Points Expiring', value: '500', sub: 'By Mar 2025' },
                ].map((s, i) => (
                  <div key={i} className="bg-white rounded-2xl p-5 border border-[#E8D5B0] text-center">
                    <p className="text-2xl font-bold text-[#C0392B]">{s.value}</p>
                    <p className="text-sm font-medium text-[#2C1810]">{s.label}</p>
                    <p className="text-xs text-[#8B4513]">{s.sub}</p>
                  </div>
                ))}
              </div>

              <div className="bg-white rounded-2xl p-6 border border-[#E8D5B0]">
                <h3 className="font-bold text-[#2C1810] mb-4">How to Earn Points</h3>
                <div className="space-y-3">
                  {[
                    { icon: '🛍️', action: 'Every ৳100 spent', points: '+10 pts' },
                    { icon: '⭐', action: 'Write a product review', points: '+50 pts' },
                    { icon: '👥', action: 'Refer a friend', points: '+200 pts' },
                    { icon: '🎂', action: 'Birthday bonus', points: '+500 pts' },
                    { icon: '📱', action: 'Download the Aarong app', points: '+100 pts' },
                  ].map((r, i) => (
                    <div key={i} className="flex items-center justify-between p-3 bg-[#FAF7F2] rounded-xl border border-[#E8D5B0]">
                      <div className="flex items-center gap-3">
                        <span className="text-xl">{r.icon}</span>
                        <span className="text-sm text-[#3D2B1F]">{r.action}</span>
                      </div>
                      <span className="font-bold text-[#27AE60] text-sm">{r.points}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Wishlist in account */}
          {activeSection === 'wishlist' && (
            <div className="bg-white rounded-2xl p-6 border border-[#E8D5B0] shadow-sm">
              <h3 className="font-bold text-[#2C1810] text-lg mb-5">My Wishlist ({wishlist.length} items)</h3>
              {wishlist.length === 0 ? (
                <div className="text-center py-12">
                  <Heart className="text-[#C8A87E] mx-auto mb-4" size={48} />
                  <p className="text-[#8B4513]">Your wishlist is empty</p>
                  <button onClick={() => setCurrentPage('category')} className="mt-4 px-6 py-3 bg-[#C0392B] text-white rounded-full text-sm">Browse Products</button>
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {wishlist.map(p => (
                    <div key={p.id} className="border border-[#E8D5B0] rounded-xl overflow-hidden hover:border-[#C0392B]/40 transition-colors">
                      <img src={p.images[0]} alt={p.name} className="w-full h-40 object-cover" />
                      <div className="p-3">
                        <p className="text-sm font-medium text-[#2C1810] line-clamp-1">{p.name}</p>
                        <p className="text-sm font-bold text-[#C0392B] mt-1">৳{p.price.toLocaleString()}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Addresses */}
          {activeSection === 'addresses' && (
            <div className="bg-white rounded-2xl p-6 border border-[#E8D5B0] shadow-sm">
              <div className="flex items-center justify-between mb-5">
                <h3 className="font-bold text-[#2C1810] text-lg">Saved Addresses</h3>
                <button className="px-4 py-2 bg-[#C0392B] text-white rounded-full text-xs font-semibold">+ Add New</button>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { label: 'Home', address: 'House 12, Road 5, Dhanmondi, Dhaka 1205', default: true },
                  { label: 'Office', address: 'Level 8, Tower A, Gulshan Avenue, Dhaka 1212', default: false },
                ].map((addr, i) => (
                  <div key={i} className={`p-4 border-2 rounded-2xl relative ${addr.default ? 'border-[#C0392B] bg-[#FEF5F3]' : 'border-[#E8D5B0]'}`}>
                    {addr.default && <span className="absolute top-3 right-3 text-[10px] bg-[#C0392B] text-white px-2 py-0.5 rounded-full font-bold">DEFAULT</span>}
                    <p className="font-bold text-[#2C1810] mb-1">{addr.label}</p>
                    <p className="text-sm text-[#6B4C3B]">{user?.name}</p>
                    <p className="text-sm text-[#6B4C3B] mt-1">{addr.address}</p>
                    <div className="flex gap-3 mt-3">
                      <button className="text-xs text-[#C0392B] hover:underline">Edit</button>
                      {!addr.default && <button className="text-xs text-[#6B4C3B] hover:text-[#C0392B] transition-colors">Set Default</button>}
                      <button className="text-xs text-[#A07850] hover:text-red-500 transition-colors">Delete</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Security */}
          {activeSection === 'security' && (
            <div className="bg-white rounded-2xl p-6 border border-[#E8D5B0] shadow-sm">
              <h3 className="font-bold text-[#2C1810] text-lg mb-5">Password & Security</h3>
              <div className="max-w-md space-y-4">
                {['Current Password', 'New Password', 'Confirm New Password'].map(label => (
                  <div key={label}>
                    <label className="block text-xs font-semibold text-[#6B4C3B] mb-1.5">{label}</label>
                    <input type="password" placeholder="••••••••"
                      className="w-full px-4 py-3 border border-[#E8D5B0] rounded-xl text-sm focus:outline-none focus:border-[#C0392B]" />
                  </div>
                ))}
                <button className="px-8 py-3 bg-[#C0392B] text-white rounded-full text-sm font-semibold hover:bg-[#A93226] transition-colors">
                  Update Password
                </button>
              </div>

              <div className="mt-8 pt-6 border-t border-[#E8D5B0]">
                <h4 className="font-semibold text-[#2C1810] mb-4">Two-Factor Authentication</h4>
                <div className="flex items-center justify-between p-4 bg-[#FAF7F2] rounded-xl border border-[#E8D5B0]">
                  <div>
                    <p className="font-medium text-[#2C1810] text-sm">SMS Authentication</p>
                    <p className="text-xs text-[#8B4513]">Receive a code on your registered mobile</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" />
                    <div className="w-11 h-6 bg-[#E8D5B0] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#C0392B]"></div>
                  </label>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AccountPage;
